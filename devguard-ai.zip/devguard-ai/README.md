# DevGuard AI

Upload a project ZIP, test an API endpoint, and have Claude explain every problem in plain language with a suggested fix.

This is the **MVP** from the project plan:

| Included | Not yet (see "Next steps") |
|---|---|
| Sign up with email verification, sign in, sign out | Password reset page |
| ZIP upload (10 MB max), safe extraction | GitHub repository connection |
| Python scan (Ruff + Bandit), JavaScript scan (ESLint) | Dependency audits (pip-audit, npm audit) |
| Severity-ranked findings with file, line and code | TypeScript analysis |
| API tester: GET/POST/PUT/DELETE, status, timing, JSON check, auth-failure hints, SSRF protection | Database health checker |
| Claude explanations: causes, fixes, corrected snippets | Playwright website tests, cloud monitor |
| Saved scan history and API test history | |

Static analysis finds many classes of bugs and security problems, **not every bug in every application**. The app says so in its own UI.

## Quick start (one command)

**Windows:** extract the ZIP, then double-click `start.bat` (or run `.\start.bat` in Command Prompt or PowerShell).
**Mac / Linux / Git Bash:** run `bash start.sh`.

Either script installs everything, asks for your Supabase and Anthropic keys once, starts the backend and frontend, and gives you the address to open (http://localhost:3000; start.bat opens your browser for you). Other commands: `setup`, `run`, `config`, `test` (for example `start.bat config` to re-enter your keys).
On Windows the two servers run in their own windows; press a key in the launcher window to stop both, or close the two windows. Errors are saved in the `logs/` folder.
The step-by-step manual instructions below do the same thing by hand.

## Folder structure

```
devguard-ai/
├── backend/                  Python FastAPI
│   ├── app/
│   │   ├── main.py           app, CORS, upload-size guard
│   │   ├── config.py         environment variables
│   │   ├── db.py             SQLAlchemy models (scans, api_tests)
│   │   ├── auth.py           verifies Supabase tokens + email confirmation
│   │   ├── routes/           /api/scans, /api/api-tests
│   │   ├── scanners/         zip_safe.py, runner.py, normalize.py
│   │   ├── services/         api_tester.py, ai_analyzer.py
│   │   └── utils/            ssrf.py, ratelimit.py
│   ├── tests/                55 automated tests
│   └── tools/                eslint/ (pinned ESLint + our config), check.py (used by start.bat)
├── start.bat / start.sh      one-command setup and launcher (Windows / Mac, Linux)
├── frontend/                 Next.js 14 + TypeScript + Tailwind
│   ├── app/                  landing, login, register, dashboard, scan report, API tester
│   ├── components/           AuthForm, AuthGuard, Nav, SeverityStrip
│   └── lib/                  Supabase client, API client, types
└── docs/CV.md                CV entry and interview talking points
```

## What you need

- Python 3.11 or newer, Node.js 18 or newer, Git
- A free [Supabase](https://supabase.com) project (login and, optionally, the database)
- An [Anthropic API key](https://console.anthropic.com) (only needed for the "Explain with Claude" button)

## 1. Set up Supabase

1. Create a project. Under **Project Settings -> API** copy the **Project URL** and the **anon public** key.
2. Under **Authentication -> URL Configuration** set **Site URL** to `http://localhost:3000` and add `http://localhost:3000/dashboard` to **Redirect URLs**. The verification email link needs this.
3. Under **Authentication -> Providers -> Email** keep **Confirm email** switched on. The backend refuses unverified users anyway.
4. Optional: to store data in Supabase PostgreSQL instead of a local SQLite file, copy the **Session pooler** connection string from **Project Settings -> Database** into `DATABASE_URL`, and run `pip install -r requirements-postgres.txt`. The backend creates its tables on start and turns on Row Level Security for them, so they cannot be read through Supabase's public REST API.

## 2. Run the backend

```bash
cd backend
python -m venv venv
source venv/bin/activate            # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env                # Windows: copy .env.example .env  (then edit it)

# optional but recommended: enables JavaScript scanning
cd tools/eslint && npm install && cd ../..

uvicorn app.main:app --reload --port 8000
```

Open http://localhost:8000/api/health. It reports whether auth and AI are configured. API docs are at http://localhost:8000/docs.

If Ruff, Bandit or ESLint is missing, the scan still works and the report says which tool did not run and why.

## 3. Run the frontend

```bash
cd frontend
npm install
cp .env.local.example .env.local    # Windows: copy .env.local.example .env.local  (then edit it)
npm run dev
```

Open http://localhost:3000, create an account, click the link in the verification email, sign in, and upload a ZIP of any small Python or JavaScript project.

## 4. Run the tests

```bash
cd backend
pip install -r requirements-dev.txt
pytest
```

The tests cover malicious ZIP handling (path traversal, zip bombs, symlinks), SSRF protection (including DNS-rebinding and redirect attacks, against a real local server), scanner output parsing, and validation of Claude's responses. They need no network access and no API keys.

## How it works

```
Browser (Next.js)  --sign in-->  Supabase Auth
      |  access token
      v
FastAPI  --verifies token + email confirmed-->  Supabase Auth
   |-- POST /api/scans   save ZIP to temp folder -> safe extract -> Ruff/Bandit/ESLint -> findings in DB
   |-- POST /api/scans/{id}/analyze   top 15 findings -> Claude -> validated JSON -> saved
   |-- POST /api/api-tests   validate URL (SSRF) -> request -> diagnosis -> history
```

## Security decisions worth knowing

- **Uploaded code is never executed.** It is only read by static-analysis tools, which run with a stripped environment (no API keys), a timeout, and our own config. Project config files are ignored because an ESLint config is JavaScript.
- **ZIP safety:** path traversal, absolute paths, symlinks, password-protected archives, zip bombs and oversized files are rejected; sizes are enforced on the bytes actually written, not on what the ZIP header claims.
- **SSRF protection** in the API tester: public addresses only, checked before every request and redirect, checked again on the real connected address, credentials dropped on cross-site redirects, response and request size caps.
- **Prompt injection:** scanned text reaches Claude as escaped data with an "untrusted" instruction, and Claude's reply must pass strict schema validation.
- **Secrets:** the Anthropic key and database password exist only in `backend/.env`. API-test headers (which may contain tokens) are never stored.
- **Privacy:** every query is filtered by the signed-in user's id; other users' scans return 404.

## Known limits of this MVP

- Scans run inside the API process. For real deployment, run them in a container with no network and CPU/memory limits.
- The rate limiter is in memory (fine for one server process).
- The upload-size guard relies on the `Content-Length` header; also set a body limit on your reverse proxy.
- Tables are created automatically. Use Alembic migrations once the schema starts changing.
- The frontend login guard is a convenience. The real protection is that the API rejects any request without a valid token from a verified user.

## Next steps

Build these one at a time, testing each before the next. Good order:

1. Password reset page (`supabase.auth.resetPasswordForEmail`).
2. Dependency audit: `pip-audit` and `npm audit` for `requirements.txt` / `package.json` found in the ZIP.
3. Database health checker (read-only PostgreSQL connection: connectivity, tables exist, slow queries).
4. Website tester with Playwright (broken links, console errors) plus SSL expiry and uptime checks.
5. GitHub repository import, then GitHub Actions and Docker.

When you add a module, extend `docs/CV.md` only after it works end to end.

## Deploying

Frontend on Vercel (set the three `NEXT_PUBLIC_*` variables), backend on Render or Railway (set the variables from `backend/.env.example`, start command `uvicorn app.main:app --host 0.0.0.0 --port $PORT`). Set `FRONTEND_ORIGINS` on the backend to your Vercel URL, and add that URL to Supabase **Redirect URLs**.
