"""Authentication: the frontend signs users in with Supabase Auth and sends us the
access token. We ask Supabase who the token belongs to (this works whatever
signing algorithm the project uses) and refuse unverified e-mail addresses."""
import hashlib
import threading
import time

import requests
from fastapi import Header, HTTPException

from app import config

_CACHE_SECONDS = 60
_CACHE_MAX = 1000
_cache: dict[str, tuple[float, dict]] = {}
_lock = threading.Lock()


def get_current_user(authorization: str | None = Header(default=None)) -> dict:
    if not config.SUPABASE_URL or not config.SUPABASE_ANON_KEY:
        raise HTTPException(503, "Authentication is not configured on the server (SUPABASE_URL / SUPABASE_ANON_KEY).")
    if not authorization or not authorization.lower().startswith("bearer "):
        raise HTTPException(401, "Sign in to continue.")

    token = authorization[7:].strip()
    key = hashlib.sha256(token.encode()).hexdigest()
    now = time.monotonic()
    with _lock:
        hit = _cache.get(key)
        if hit and now - hit[0] < _CACHE_SECONDS:
            return hit[1]

    try:
        resp = requests.get(
            f"{config.SUPABASE_URL}/auth/v1/user",
            headers={"apikey": config.SUPABASE_ANON_KEY, "Authorization": f"Bearer {token}"},
            timeout=8,
        )
    except requests.RequestException:
        raise HTTPException(503, "Could not reach the authentication service. Try again shortly.") from None
    if resp.status_code != 200:
        raise HTTPException(401, "Your session is invalid or has expired. Please sign in again.")

    data = resp.json()
    if not (data.get("email_confirmed_at") or data.get("confirmed_at")):
        raise HTTPException(403, "Verify your email address before using DevGuard AI. Check your inbox for the link.")

    user = {"id": data["id"], "email": data.get("email")}
    with _lock:
        if len(_cache) >= _CACHE_MAX:
            _cache.clear()
        _cache[key] = (now, user)
    return user
