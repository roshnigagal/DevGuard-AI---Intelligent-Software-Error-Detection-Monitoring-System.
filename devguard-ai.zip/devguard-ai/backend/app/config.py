"""Central configuration. Every secret comes from environment variables
(or backend/.env) and is never sent to the frontend."""
import os
from pathlib import Path

from dotenv import load_dotenv

load_dotenv(Path(__file__).resolve().parent.parent / ".env")


def _int(name: str, default: int) -> int:
    try:
        return int(os.getenv(name, default))
    except ValueError:
        return default


# --- Database -------------------------------------------------------------
# Local development works out of the box with SQLite.
# For Supabase, set DATABASE_URL to your Postgres connection string.
DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./devguard.db")

# --- Supabase Auth (used to verify the user's access token) ---------------
SUPABASE_URL = os.getenv("SUPABASE_URL", "").rstrip("/")
SUPABASE_ANON_KEY = os.getenv("SUPABASE_ANON_KEY", "")

# --- Anthropic Claude -----------------------------------------------------
ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY", "")
ANTHROPIC_MODEL = os.getenv("ANTHROPIC_MODEL", "claude-sonnet-5-5")

# --- CORS -----------------------------------------------------------------
FRONTEND_ORIGINS = [
    o.strip()
    for o in os.getenv("FRONTEND_ORIGINS", "http://localhost:3000,http://127.0.0.1:3000").split(",")
    if o.strip()
]

# --- Limits ---------------------------------------------------------------
MAX_UPLOAD_BYTES = _int("MAX_UPLOAD_MB", 10) * 1024 * 1024
# multipart framing adds a little overhead on top of the file itself
MAX_REQUEST_BYTES = MAX_UPLOAD_BYTES + 512 * 1024
