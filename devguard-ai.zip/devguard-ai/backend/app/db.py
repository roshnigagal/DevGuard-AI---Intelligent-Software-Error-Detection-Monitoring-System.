"""Database models and session handling (SQLAlchemy 2.0).

SQLite is used by default for local development; set DATABASE_URL to a
PostgreSQL connection string (for example Supabase) for the real thing."""
import logging
import uuid
from datetime import datetime, timezone

from sqlalchemy import JSON, Boolean, DateTime, Float, Integer, String, Text, create_engine, text
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, sessionmaker

from app import config

logger = logging.getLogger("devguard.db")


def _normalise_url(url: str) -> str:
    # Supabase hands out postgres:// or postgresql:// URLs; SQLAlchemy needs a driver name.
    for prefix in ("postgres://", "postgresql://"):
        if url.startswith(prefix):
            return "postgresql+psycopg2://" + url[len(prefix):]
    return url


DATABASE_URL = _normalise_url(config.DATABASE_URL)
IS_SQLITE = DATABASE_URL.startswith("sqlite")

if not IS_SQLITE:
    try:
        import psycopg2  # noqa: F401
    except ImportError:
        raise RuntimeError(
            "DATABASE_URL points to PostgreSQL but the driver is not installed. "
            "Run: pip install -r requirements-postgres.txt  (or remove DATABASE_URL to use SQLite)."
        ) from None

engine = create_engine(
    DATABASE_URL,
    pool_pre_ping=True,
    connect_args={"check_same_thread": False} if IS_SQLITE else {},
)
SessionLocal = sessionmaker(bind=engine, expire_on_commit=False)


class Base(DeclarativeBase):
    pass


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _iso(dt: datetime | None) -> str | None:
    if dt is None:
        return None
    if dt.tzinfo is None:  # SQLite drops the timezone
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.isoformat()


def _new_id() -> str:
    return str(uuid.uuid4())


class Scan(Base):
    __tablename__ = "scans"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_new_id)
    user_id: Mapped[str] = mapped_column(String(64), index=True)
    filename: Mapped[str] = mapped_column(String(255))
    status: Mapped[str] = mapped_column(String(20), default="running")  # running | completed | failed
    languages: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    summary: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    tools: Mapped[list | None] = mapped_column(JSON, nullable=True)
    findings: Mapped[list | None] = mapped_column(JSON, nullable=True)
    ai_analysis: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    error: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)
    finished_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    def to_list_item(self) -> dict:
        """Light version for the history list (does not touch the findings column)."""
        return {
            "id": self.id,
            "filename": self.filename,
            "status": self.status,
            "summary": self.summary,
            "languages": self.languages,
            "error": self.error,
            "created_at": _iso(self.created_at),
            "finished_at": _iso(self.finished_at),
            "has_ai": bool(self.ai_analysis),
        }

    def to_detail(self) -> dict:
        return {
            **self.to_list_item(),
            "tools": self.tools,
            "findings": self.findings,
            "ai_analysis": self.ai_analysis,
        }


class ApiTest(Base):
    __tablename__ = "api_tests"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_new_id)
    user_id: Mapped[str] = mapped_column(String(64), index=True)
    url: Mapped[str] = mapped_column(String(2048))
    method: Mapped[str] = mapped_column(String(10))
    ok: Mapped[bool] = mapped_column(Boolean, default=False)
    status_code: Mapped[int | None] = mapped_column(Integer, nullable=True)
    response_time_ms: Mapped[float | None] = mapped_column(Float, nullable=True)
    error_type: Mapped[str | None] = mapped_column(String(30), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "url": self.url,
            "method": self.method,
            "ok": self.ok,
            "status_code": self.status_code,
            "response_time_ms": self.response_time_ms,
            "error_type": self.error_type,
            "created_at": _iso(self.created_at),
        }


def init_db() -> None:
    """Create tables, lock down Postgres, and fail scans that a restart interrupted."""
    Base.metadata.create_all(engine)

    if not IS_SQLITE:
        # Supabase exposes every table in the public schema through its REST API.
        # Row Level Security with no policies blocks that route completely, while
        # this backend (which connects as the database owner) keeps full access.
        with engine.begin() as conn:
            for table in (Scan.__tablename__, ApiTest.__tablename__):
                try:
                    conn.execute(text(f'ALTER TABLE "{table}" ENABLE ROW LEVEL SECURITY'))
                except Exception:  # not the table owner, etc.
                    logger.warning("Could not enable row level security on %s", table)

    with SessionLocal() as db:
        stuck = db.query(Scan).filter(Scan.status == "running").all()
        for scan in stuck:
            scan.status = "failed"
            scan.error = "The server restarted while this scan was running. Upload the project again."
            scan.finished_at = _now()
        db.commit()


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
