import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app import config
from app.db import init_db
from app.routes import api_tests, scans

logging.basicConfig(level=logging.INFO)


@asynccontextmanager
async def lifespan(_app: FastAPI):
    init_db()
    yield


app = FastAPI(title="DevGuard AI API", version="0.1.0", lifespan=lifespan)


@app.middleware("http")
async def limit_request_size(request: Request, call_next):
    """Reject oversized uploads early using the Content-Length header.
    (Also set a body size limit on your reverse proxy in production.)"""
    length = request.headers.get("content-length")
    if length and length.isdigit() and int(length) > config.MAX_REQUEST_BYTES:
        return JSONResponse(
            {"detail": f"Upload too large. The limit is {config.MAX_UPLOAD_BYTES // (1024 * 1024)} MB."},
            status_code=413,
        )
    return await call_next(request)


# Added last so it is the outermost layer and also decorates error responses.
app.add_middleware(
    CORSMiddleware,
    allow_origins=config.FRONTEND_ORIGINS,
    allow_credentials=False,
    allow_methods=["GET", "POST", "DELETE"],
    allow_headers=["Authorization", "Content-Type"],
)

app.include_router(scans.router)
app.include_router(api_tests.router)


@app.get("/api/health")
def health():
    return {
        "status": "ok",
        "auth_configured": bool(config.SUPABASE_URL and config.SUPABASE_ANON_KEY),
        "ai_configured": bool(config.ANTHROPIC_API_KEY),
    }
