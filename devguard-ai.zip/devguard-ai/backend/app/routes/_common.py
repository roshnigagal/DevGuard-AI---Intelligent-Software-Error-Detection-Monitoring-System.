from fastapi import HTTPException
from sqlalchemy.orm import Session

from app.db import Scan
from app.utils.ratelimit import RateLimitExceeded, check_rate_limit


def enforce_rate_limit(key: str, limit: int, window_seconds: int) -> None:
    try:
        check_rate_limit(key, limit, window_seconds)
    except RateLimitExceeded as exc:
        raise HTTPException(
            429, str(exc), headers={"Retry-After": str(exc.retry_after)}
        ) from None


def get_owned_scan(db: Session, scan_id: str, user_id: str) -> Scan:
    """Return the scan only if it belongs to this user (otherwise 404, never 403,
    so IDs of other users' scans cannot be probed)."""
    scan = db.get(Scan, scan_id)
    if scan is None or scan.user_id != user_id:
        raise HTTPException(404, "Scan not found.")
    return scan
