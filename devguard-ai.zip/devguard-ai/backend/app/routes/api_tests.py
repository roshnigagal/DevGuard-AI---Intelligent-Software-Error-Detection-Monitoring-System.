from typing import Literal

from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.auth import get_current_user
from app.db import ApiTest, get_db
from app.routes._common import enforce_rate_limit
from app.services.api_tester import run_api_test

router = APIRouter(prefix="/api/api-tests", tags=["api-tests"])


class ApiTestRequest(BaseModel):
    url: str = Field(min_length=1, max_length=2048)
    method: Literal["GET", "POST", "PUT", "DELETE"] = "GET"
    headers: dict[str, str] = Field(default_factory=dict)
    body: str | None = Field(default=None, max_length=100_000)
    timeout_seconds: int = Field(default=10, ge=1, le=15)


@router.post("")
def create_api_test(
    payload: ApiTestRequest,
    user: dict = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    enforce_rate_limit(f"apitest:{user['id']}", limit=30, window_seconds=600)
    result = run_api_test(
        payload.url, payload.method, payload.headers, payload.body, payload.timeout_seconds
    )
    # Keep history for requests that were really attempted. Headers (which may hold
    # secrets) and bodies are never stored.
    if result["error_type"] not in ("invalid_request", "blocked"):
        db.add(
            ApiTest(
                user_id=user["id"], url=result["url"][:2048], method=result["method"],
                ok=result["ok"], status_code=result["status_code"],
                response_time_ms=result["response_time_ms"], error_type=result["error_type"],
            )
        )
        db.commit()
    return result


@router.get("")
def list_api_tests(user: dict = Depends(get_current_user), db: Session = Depends(get_db)):
    rows = db.scalars(
        select(ApiTest)
        .where(ApiTest.user_id == user["id"])
        .order_by(ApiTest.created_at.desc())
        .limit(30)
    ).all()
    return [row.to_dict() for row in rows]
