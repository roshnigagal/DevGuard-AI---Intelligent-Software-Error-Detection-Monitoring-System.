import logging
import os
import shutil
import tempfile
from datetime import datetime, timezone

from fastapi import APIRouter, BackgroundTasks, Depends, File, HTTPException, UploadFile
from sqlalchemy import func, select
from sqlalchemy.orm import Session, defer

from app import config
from app.auth import get_current_user
from app.db import Scan, SessionLocal, get_db
from app.routes._common import enforce_rate_limit, get_owned_scan
from app.scanners.runner import scan_directory
from app.scanners.zip_safe import UnsafeZipError, looks_like_zip, safe_extract
from app.services.ai_analyzer import AIAnalysisError, analyze_findings

logger = logging.getLogger("devguard.scans")
router = APIRouter(prefix="/api/scans", tags=["scans"])


def run_scan_job(scan_id: str, work_dir: str) -> None:
    """Background job: extract the ZIP safely, scan it, store the result, clean up."""
    db = SessionLocal()
    try:
        scan = db.get(Scan, scan_id)
        if scan is None:
            return
        try:
            extract_dir = os.path.join(work_dir, "src")
            os.makedirs(extract_dir)
            safe_extract(os.path.join(work_dir, "upload.zip"), extract_dir)
            result = scan_directory(extract_dir)
            scan.languages = result["languages"]
            scan.tools = result["tools"]
            scan.summary = result["summary"]
            scan.findings = result["findings"]
            scan.status = "completed"
        except UnsafeZipError as exc:
            scan.status, scan.error = "failed", str(exc)
        except Exception:
            logger.exception("Scan %s failed", scan_id)
            scan.status = "failed"
            scan.error = "The scan failed unexpectedly. Try again; if it keeps failing, check the server logs."
        scan.finished_at = datetime.now(timezone.utc)
        db.commit()
    finally:
        shutil.rmtree(work_dir, ignore_errors=True)
        db.close()


@router.post("", status_code=202)
def create_scan(
    background_tasks: BackgroundTasks,
    file: UploadFile = File(...),
    user: dict = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    enforce_rate_limit(f"scan:{user['id']}", limit=10, window_seconds=3600)
    running = db.scalar(
        select(func.count()).select_from(Scan).where(Scan.user_id == user["id"], Scan.status == "running")
    )
    if running and running >= 2:
        raise HTTPException(429, "You already have scans in progress. Wait for them to finish first.")

    name = os.path.basename(file.filename or "project.zip")[:200]
    if not name.lower().endswith(".zip"):
        raise HTTPException(400, "Upload a .zip file.")

    work_dir = tempfile.mkdtemp(prefix="devguard_scan_")
    zip_path = os.path.join(work_dir, "upload.zip")
    try:
        size = 0
        with open(zip_path, "wb") as out:
            while True:
                chunk = file.file.read(1024 * 1024)
                if not chunk:
                    break
                size += len(chunk)
                if size > config.MAX_UPLOAD_BYTES:
                    raise HTTPException(
                        413,
                        f"The ZIP is larger than {config.MAX_UPLOAD_BYTES // (1024 * 1024)} MB. "
                        "Remove node_modules, virtual environments and build folders, then try again.",
                    )
                out.write(chunk)
        if size == 0:
            raise HTTPException(400, "The uploaded file is empty.")
        if not looks_like_zip(zip_path):
            raise HTTPException(400, "That file is not a valid ZIP archive.")
    except Exception:
        shutil.rmtree(work_dir, ignore_errors=True)
        raise

    scan = Scan(user_id=user["id"], filename=name, status="running")
    db.add(scan)
    db.commit()
    background_tasks.add_task(run_scan_job, scan.id, work_dir)
    return {"id": scan.id, "status": scan.status}


@router.get("")
def list_scans(user: dict = Depends(get_current_user), db: Session = Depends(get_db)):
    rows = db.scalars(
        select(Scan)
        .where(Scan.user_id == user["id"])
        .options(defer(Scan.findings), defer(Scan.tools))
        .order_by(Scan.created_at.desc())
        .limit(50)
    ).all()
    return [row.to_list_item() for row in rows]


@router.get("/{scan_id}")
def get_scan(scan_id: str, user: dict = Depends(get_current_user), db: Session = Depends(get_db)):
    return get_owned_scan(db, scan_id, user["id"]).to_detail()


@router.delete("/{scan_id}", status_code=204)
def delete_scan(scan_id: str, user: dict = Depends(get_current_user), db: Session = Depends(get_db)):
    db.delete(get_owned_scan(db, scan_id, user["id"]))
    db.commit()


@router.post("/{scan_id}/analyze")
def analyze_scan(scan_id: str, user: dict = Depends(get_current_user), db: Session = Depends(get_db)):
    scan = get_owned_scan(db, scan_id, user["id"])
    if scan.status != "completed":
        raise HTTPException(409, "The scan has not finished yet.")
    if not scan.findings:
        raise HTTPException(400, "This scan has no findings to analyse.")
    enforce_rate_limit(f"ai:{user['id']}", limit=10, window_seconds=3600)
    try:
        analysis = analyze_findings(scan.findings)
    except AIAnalysisError as exc:
        raise HTTPException(exc.status_code, str(exc)) from None
    scan.ai_analysis = analysis
    db.commit()
    return analysis
