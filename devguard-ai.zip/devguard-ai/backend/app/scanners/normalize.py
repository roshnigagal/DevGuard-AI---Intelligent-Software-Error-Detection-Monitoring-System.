"""Turn the raw JSON output of Ruff, Bandit and ESLint into one common
"finding" format. Pure functions, no framework imports, easy to unit-test.

A finding looks like:
  {"tool", "rule_id", "severity", "category", "file", "line", "column",
   "message", "more_info", "code_line"}
"""
import json
import os
from pathlib import Path

SEVERITIES = ("critical", "high", "medium", "low", "info")
CATEGORIES = ("bug", "security", "quality")
_RANK = {name: i for i, name in enumerate(SEVERITIES)}
MAX_CODE_LINE_CHARS = 300


class ToolOutputError(ValueError):
    """A tool printed something we could not parse."""


def severity_rank(severity: str) -> int:
    return _RANK.get(severity, len(SEVERITIES))


def _rel(path: str, root: str) -> str:
    try:
        rel = os.path.relpath(path, root)
    except ValueError:  # different drive on Windows
        rel = path
    return rel.replace("\\", "/")


def _loads(raw: str):
    raw = (raw or "").strip()
    if not raw:
        raise ToolOutputError("The tool produced no output.")
    try:
        return json.loads(raw)
    except json.JSONDecodeError as exc:
        raise ToolOutputError("The tool output was not valid JSON.") from exc


def _finding(tool, rule_id, severity, category, file, line, column, message, more_info=None):
    return {
        "tool": tool,
        "rule_id": rule_id,
        "severity": severity,
        "category": category,
        "file": file,
        "line": line,
        "column": column,
        "message": (message or "").strip()[:500],
        "more_info": more_info,
        "code_line": None,
    }


# --- Ruff ------------------------------------------------------------------
def _ruff_classify(code):
    if not code or code.startswith("E9"):
        return "high", "bug"  # syntax errors: the file cannot run at all
    if code in {"F821", "F822", "F823"} or code.startswith(("F63", "F7")):
        return "high", "bug"  # undefined names, invalid comparisons, misplaced statements
    if code in {"F401", "F841", "F811", "F541"}:
        return "low", "quality"  # unused imports/variables, redefinitions
    if code.startswith(("F", "B")):
        return "medium", "bug"
    return "low", "quality"


def parse_ruff(raw: str, root: str) -> list[dict]:
    data = _loads(raw)
    if not isinstance(data, list):
        raise ToolOutputError("Unexpected Ruff output.")
    findings = []
    for item in data:
        code = item.get("code")
        severity, category = _ruff_classify(code)
        loc = item.get("location") or {}
        findings.append(
            _finding(
                "ruff",
                code or "syntax-error",
                severity,
                category,
                _rel(item.get("filename", ""), root),
                loc.get("row"),
                loc.get("column"),
                item.get("message"),
                item.get("url"),
            )
        )
    return findings


# --- Bandit ----------------------------------------------------------------
_BANDIT_SEVERITY = {"HIGH": "high", "MEDIUM": "medium", "LOW": "low"}


def parse_bandit(raw: str, root: str) -> list[dict]:
    data = _loads(raw)
    if not isinstance(data, dict) or not isinstance(data.get("results"), list):
        raise ToolOutputError("Unexpected Bandit output.")
    findings = []
    for item in data["results"]:
        cwe = item.get("issue_cwe") or {}
        message = item.get("issue_text", "")
        if cwe.get("id"):
            message = f"{message} (CWE-{cwe['id']})"
        findings.append(
            _finding(
                "bandit",
                item.get("test_id", "bandit"),
                _BANDIT_SEVERITY.get(str(item.get("issue_severity", "")).upper(), "low"),
                "security",
                _rel(item.get("filename", ""), root),
                item.get("line_number"),
                item.get("col_offset"),
                message,
                item.get("more_info"),
            )
        )
    return findings


# --- ESLint ----------------------------------------------------------------
_ESLINT_SECURITY_RULES = {"no-eval", "no-implied-eval", "no-new-func"}


def parse_eslint(raw: str, root: str) -> list[dict]:
    data = _loads(raw)
    if not isinstance(data, list):
        raise ToolOutputError("Unexpected ESLint output.")
    findings = []
    for file_result in data:
        rel = _rel(file_result.get("filePath", ""), root)
        for msg in file_result.get("messages", []):
            rule = msg.get("ruleId")
            if msg.get("fatal") or rule is None:
                severity, category, rule = "high", "bug", "parse-error"
            elif rule in _ESLINT_SECURITY_RULES:
                severity, category = "high", "security"
            elif msg.get("severity") == 2:
                severity, category = "medium", "bug"
            else:
                severity, category = "low", "quality"
            more = f"https://eslint.org/docs/latest/rules/{rule}" if rule != "parse-error" else None
            findings.append(
                _finding("eslint", rule, severity, category, rel,
                         msg.get("line"), msg.get("column"), msg.get("message"), more)
            )
    return findings


# --- Shared helpers ----------------------------------------------------------
def read_code_line(root: str, rel_file: str, line) -> str | None:
    """Return the source line a finding points at (trimmed), or None."""
    if not isinstance(line, int) or line < 1:
        return None
    try:
        root_path = Path(root).resolve()
        path = (root_path / rel_file).resolve()
        if not path.is_relative_to(root_path) or not path.is_file():
            return None
        with open(path, "r", encoding="utf-8", errors="replace") as fh:
            for number, text in enumerate(fh, start=1):
                if number == line:
                    return text.rstrip("\r\n")[:MAX_CODE_LINE_CHARS]
    except OSError:
        return None
    return None


def build_summary(findings: list[dict]) -> dict:
    by_severity = {s: 0 for s in SEVERITIES}
    by_tool: dict[str, int] = {}
    by_category: dict[str, int] = {}
    for f in findings:
        by_severity[f["severity"]] = by_severity.get(f["severity"], 0) + 1
        by_tool[f["tool"]] = by_tool.get(f["tool"], 0) + 1
        by_category[f["category"]] = by_category.get(f["category"], 0) + 1
    return {
        "total": len(findings),
        "by_severity": by_severity,
        "by_tool": by_tool,
        "by_category": by_category,
    }
