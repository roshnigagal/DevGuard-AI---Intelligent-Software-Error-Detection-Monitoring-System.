"""Runs the analysis tools on an already-extracted project folder.

Safety notes
  * Uploaded code is only READ by static-analysis tools; it is never executed.
  * Tools run with a minimal environment so they cannot see our secrets
    (ANTHROPIC_API_KEY, DATABASE_URL, ...).
  * Project config files (ruff.toml, .eslintrc, eslint.config.js ...) are
    ignored on purpose: ESLint configs are JavaScript and would run code.
    We always pass our own config.
  * Every tool has a timeout.
For production, also run scans inside a container with no network access.
"""
import os
import shutil
import subprocess
import sys
import tempfile
from dataclasses import dataclass
from pathlib import Path

from app.scanners import normalize as N

TOOLS_DIR = Path(__file__).resolve().parents[2] / "tools" / "eslint"
TOOL_TIMEOUT_SECONDS = 90
MAX_FINDINGS = 500

PY_EXT = {".py"}
JS_EXT = {".js", ".jsx", ".mjs", ".cjs"}
TS_EXT = {".ts", ".tsx"}


@dataclass
class ToolRun:
    returncode: int | None = None
    stdout: str = ""
    stderr: str = ""
    timed_out: bool = False
    not_found: bool = False


def detect_languages(root: str) -> dict[str, int]:
    counts = {"python": 0, "javascript": 0, "typescript": 0}
    for _dir, _subdirs, files in os.walk(root):
        for name in files:
            ext = os.path.splitext(name)[1].lower()
            if ext in PY_EXT:
                counts["python"] += 1
            elif ext in JS_EXT:
                counts["javascript"] += 1
            elif ext in TS_EXT:
                counts["typescript"] += 1
    return counts


def _clean_env(home: str) -> dict[str, str]:
    env = {
        "PATH": os.environ.get("PATH", ""),
        "HOME": home,
        "LANG": "C.UTF-8",
        "PYTHONIOENCODING": "utf-8",
        "NO_COLOR": "1",
    }
    for key in ("SYSTEMROOT", "TEMP", "TMP"):  # needed on Windows
        if key in os.environ:
            env[key] = os.environ[key]
    return env


def _run(cmd: list[str], cwd: str, env: dict[str, str]) -> ToolRun:
    try:
        proc = subprocess.run(
            cmd, cwd=cwd, env=env, capture_output=True, text=True,
            encoding="utf-8", errors="replace", stdin=subprocess.DEVNULL,
            timeout=TOOL_TIMEOUT_SECONDS,
        )
    except subprocess.TimeoutExpired:
        return ToolRun(timed_out=True)
    except FileNotFoundError:
        return ToolRun(not_found=True)
    return ToolRun(proc.returncode, proc.stdout, proc.stderr)


def _status(name: str, status: str, findings: int = 0, detail: str = "") -> dict:
    return {"name": name, "status": status, "findings": findings, "detail": detail}


def _run_python_tool(name, cmd, parser, root, env, ok_codes=(0, 1)):
    run = _run(cmd, root, env)
    if run.timed_out:
        return [], _status(name, "timeout", detail=f"{name} took longer than {TOOL_TIMEOUT_SECONDS}s.")
    if run.not_found or "No module named" in run.stderr:
        return [], _status(name, "skipped", detail=f"{name} is not installed (pip install {name}).")
    if run.returncode not in ok_codes:
        return [], _status(name, "error", detail=(run.stderr or "Unknown error").strip()[:200])
    try:
        findings = parser(run.stdout, root)
    except N.ToolOutputError as exc:
        return [], _status(name, "error", detail=str(exc))
    return findings, _status(name, "ok", len(findings))


def _run_ruff(root, env):
    cmd = [
        sys.executable, "-m", "ruff", "check", "--isolated", "--no-cache", "--exit-zero",
        "--target-version", "py312", "--select", "E,F,B", "--ignore", "E501",
        "--output-format", "json", root,
    ]
    return _run_python_tool("ruff", cmd, N.parse_ruff, root, env)


def _run_bandit(root, env):
    # B101 (assert used) is skipped: it is mostly noise from test files.
    cmd = [sys.executable, "-m", "bandit", "-r", root, "-f", "json", "-q", "--exit-zero", "-s", "B101"]
    return _run_python_tool("bandit", cmd, N.parse_bandit, root, env)


def _run_eslint(root, env):
    eslint_js = TOOLS_DIR / "node_modules" / "eslint" / "bin" / "eslint.js"
    node = shutil.which("node")
    if not node or not eslint_js.exists():
        return [], _status(
            "eslint", "skipped",
            detail="ESLint is not installed (run 'npm install' inside backend/tools/eslint).",
        )
    cmd = [
        node, str(eslint_js), "-c", str(TOOLS_DIR / "eslint.config.mjs"),
        "--format", "json", "--no-error-on-unmatched-pattern", ".",
    ]
    run = _run(cmd, root, env)
    if run.timed_out:
        return [], _status("eslint", "timeout", detail=f"eslint took longer than {TOOL_TIMEOUT_SECONDS}s.")
    if run.not_found:
        return [], _status("eslint", "skipped", detail="Node.js was not found.")
    if run.returncode not in (0, 1):
        return [], _status("eslint", "error", detail=(run.stderr or "Unknown error").strip()[:200])
    try:
        findings = N.parse_eslint(run.stdout, root)
    except N.ToolOutputError as exc:
        return [], _status("eslint", "error", detail=str(exc))
    return findings, _status("eslint", "ok", len(findings))


def scan_directory(root: str) -> dict:
    """Scan an extracted project. Returns findings, summary, tool statuses and languages."""
    root = str(Path(root).resolve())
    languages = detect_languages(root)
    notes: list[str] = []
    findings: list[dict] = []
    tools: list[dict] = []

    home = tempfile.mkdtemp(prefix="devguard_home_")
    try:
        env = _clean_env(home)
        if languages["python"]:
            for runner in (_run_ruff, _run_bandit):
                found, status = runner(root, env)
                findings += found
                tools.append(status)
        if languages["javascript"]:
            found, status = _run_eslint(root, env)
            findings += found
            tools.append(status)
    finally:
        shutil.rmtree(home, ignore_errors=True)

    if languages["typescript"]:
        notes.append("TypeScript files were found but are not analysed in this version.")
    if not languages["python"] and not languages["javascript"]:
        notes.append("No Python or JavaScript files were found, so nothing was scanned.")
    for status in tools:
        if status["status"] != "ok":
            notes.append(f"{status['name']}: {status['detail']}")

    findings.sort(key=lambda f: (N.severity_rank(f["severity"]), f["file"], f["line"] or 0))
    summary = N.build_summary(findings)
    summary["total_found"] = len(findings)

    stored = findings[:MAX_FINDINGS]
    summary["truncated"] = len(findings) > len(stored)
    for index, finding in enumerate(stored):
        finding["id"] = index
        finding["code_line"] = N.read_code_line(root, finding["file"], finding["line"])

    summary["files_scanned"] = languages["python"] + languages["javascript"]
    summary["notes"] = notes
    return {"findings": stored, "summary": summary, "tools": tools, "languages": languages}
