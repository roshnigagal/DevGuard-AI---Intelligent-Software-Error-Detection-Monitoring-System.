"""Safe ZIP extraction.

Uploaded archives are untrusted. This module defends against:
  * path traversal ("../../etc/passwd", absolute paths, drive letters)
  * symlinks that point outside the extraction folder (symlinks are skipped)
  * zip bombs (limits on file count, per-file size, total size and ratio;
    sizes are enforced while streaming, not just from the ZIP header)
  * encrypted or corrupted archives
Uploaded code is never executed - it is only written to disk and read.
"""
import re
import stat
import zipfile
from dataclasses import dataclass
from pathlib import Path, PurePosixPath

# Folders we never need to scan; skipping them keeps scans fast and small.
SKIP_DIRS = {
    "node_modules", ".git", "venv", ".venv", "env", "__pycache__", ".next",
    "dist", "build", ".mypy_cache", ".pytest_cache", ".idea", ".vscode",
}
_DRIVE_RE = re.compile(r"^[A-Za-z]:")


class UnsafeZipError(ValueError):
    """The archive is invalid or breaks a safety limit. Message is user-safe."""


@dataclass(frozen=True)
class ZipLimits:
    max_entries: int = 50_000          # entries listed in the archive
    max_files: int = 2_000             # files actually extracted
    max_file_bytes: int = 5 * 1024 * 1024
    max_total_bytes: int = 50 * 1024 * 1024
    max_ratio: int = 100               # uncompressed / compressed, for files > 1 MiB


@dataclass
class ExtractResult:
    files_extracted: int
    files_skipped: int
    total_bytes: int


def looks_like_zip(path: str) -> bool:
    """Cheap magic-byte check before we hand the file to the zip parser."""
    try:
        with open(path, "rb") as fh:
            head = fh.read(4)
    except OSError:
        return False
    return head in (b"PK\x03\x04", b"PK\x05\x06")


def safe_extract(zip_path: str, dest: str, limits: ZipLimits = ZipLimits()) -> ExtractResult:
    if not looks_like_zip(zip_path):
        raise UnsafeZipError("That file is not a valid ZIP archive.")

    dest_path = Path(dest).resolve()
    dest_path.mkdir(parents=True, exist_ok=True)
    extracted = skipped = total = 0

    try:
        with zipfile.ZipFile(zip_path) as zf:
            infos = zf.infolist()
            if len(infos) > limits.max_entries:
                raise UnsafeZipError(
                    "The archive contains too many entries. Remove node_modules, "
                    "virtual environments and build folders, then zip again."
                )

            for info in infos:
                name = info.filename.replace("\\", "/")
                parts = PurePosixPath(name).parts

                if "\x00" in name or name.startswith("/") or _DRIVE_RE.match(name) or ".." in parts:
                    raise UnsafeZipError("The archive contains unsafe file paths and was rejected.")
                if info.flag_bits & 0x1:
                    raise UnsafeZipError("Password-protected ZIP files are not supported.")
                if info.is_dir():
                    continue
                if stat.S_ISLNK(info.external_attr >> 16):
                    skipped += 1  # never follow or recreate symlinks
                    continue
                if any(part in SKIP_DIRS for part in parts[:-1]):
                    skipped += 1
                    continue

                if extracted >= limits.max_files:
                    raise UnsafeZipError(
                        f"The archive has more than {limits.max_files} files. "
                        "Upload only your source code."
                    )
                if info.file_size > limits.max_file_bytes:
                    raise UnsafeZipError(
                        f"'{parts[-1][:60]}' is larger than "
                        f"{limits.max_file_bytes // (1024 * 1024)} MB. Remove large data files."
                    )
                if (
                    info.file_size > 1024 * 1024
                    and info.compress_size > 0
                    and info.file_size / info.compress_size > limits.max_ratio
                ):
                    raise UnsafeZipError("The archive looks like a zip bomb and was rejected.")

                target = (dest_path / name).resolve()
                if not target.is_relative_to(dest_path):
                    raise UnsafeZipError("The archive contains unsafe file paths and was rejected.")

                try:
                    target.parent.mkdir(parents=True, exist_ok=True)
                    written = 0
                    with zf.open(info) as src, open(target, "xb") as out:
                        while True:
                            chunk = src.read(64 * 1024)
                            if not chunk:
                                break
                            written += len(chunk)
                            total += len(chunk)
                            # enforce limits on the real bytes, not the header claim
                            if written > limits.max_file_bytes or total > limits.max_total_bytes:
                                raise UnsafeZipError(
                                    "The archive expands to more data than allowed and was rejected."
                                )
                            out.write(chunk)
                except FileExistsError:
                    skipped += 1  # duplicate name inside the archive
                    continue
                except (NotADirectoryError, IsADirectoryError):
                    raise UnsafeZipError("The archive has an invalid folder structure.") from None
                extracted += 1
    except zipfile.BadZipFile:
        raise UnsafeZipError("The ZIP file is corrupted.") from None
    except (RuntimeError, NotImplementedError, EOFError):
        raise UnsafeZipError("The ZIP file uses an unsupported format or is corrupted.") from None

    if extracted == 0:
        raise UnsafeZipError("The archive contains no files to scan.")
    return ExtractResult(extracted, skipped, total)
