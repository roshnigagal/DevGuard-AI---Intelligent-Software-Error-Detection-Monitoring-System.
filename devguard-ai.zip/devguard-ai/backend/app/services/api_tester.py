"""API tester: sends one request to a user-supplied URL and diagnoses the result.

Defences against abuse
  * SSRF: the URL is validated (public addresses only) before every request AND
    before every redirect hop. A second check inspects the address the socket
    really connected to, which defeats DNS-rebinding tricks.
  * Redirects are followed manually (max 3) so each hop is re-validated.
  * Credentials are dropped if a redirect leaves the original site.
  * Response size (1 MB), request size (100 KB) and total time are capped.
  * Headers and bodies are never stored.
"""
import json
import re
import time
from urllib.parse import urljoin, urlsplit

import requests
from requests.adapters import HTTPAdapter
from requests.utils import get_encoding_from_headers
from urllib3.connection import HTTPConnection, HTTPSConnection
from urllib3.connectionpool import HTTPConnectionPool, HTTPSConnectionPool

from app.utils.ssrf import BlockedTargetError, DNSResolutionError, is_public_ip, validate_url

USER_AGENT = "DevGuardAI-APITester/1.0"
ALLOWED_METHODS = {"GET", "POST", "PUT", "DELETE"}
MAX_REDIRECTS = 3
MAX_RESPONSE_BYTES = 1_000_000
MAX_BODY_BYTES = 100_000
PREVIEW_CHARS = 2000
REDIRECT_CODES = {301, 302, 303, 307, 308}
SLOW_MS, VERY_SLOW_MS = 1000, 3000

FORBIDDEN_HEADERS = {
    "host", "content-length", "transfer-encoding", "connection", "upgrade", "te",
    "trailer", "keep-alive", "expect", "proxy-authorization", "proxy-connection",
}
_HEADER_NAME_RE = re.compile(r"^[A-Za-z0-9-]{1,64}$")

ERROR_MESSAGES = {
    "dns_error": "The host name could not be resolved. Check the domain for typos and make sure its DNS records exist.",
    "connection_refused": "The server refused the connection. Check that the service is running and that the port is correct.",
    "timeout": "The request timed out. The server may be overloaded, a firewall may be dropping traffic, or the endpoint is very slow.",
    "ssl_error": "The TLS/SSL handshake failed. The certificate may be expired, self-signed, issued for a different domain, or incomplete.",
    "network_error": "A network error interrupted the request.",
}


class InvalidRequest(ValueError):
    pass


# --- Connect-time SSRF check ------------------------------------------------
def _verify_peer(sock) -> None:
    """Close the socket if it connected to a non-public address."""
    try:
        peer_ip = sock.getpeername()[0]
    except OSError:
        return
    if not is_public_ip(peer_ip):
        try:
            sock.close()
        except OSError:
            pass
        raise BlockedTargetError("Connection blocked: the server address is private or reserved.")


class _SafeHTTPConnection(HTTPConnection):
    def _new_conn(self):
        sock = super()._new_conn()
        _verify_peer(sock)
        return sock


class _SafeHTTPSConnection(HTTPSConnection):
    def _new_conn(self):
        sock = super()._new_conn()
        _verify_peer(sock)
        return sock


class _SafeHTTPPool(HTTPConnectionPool):
    ConnectionCls = _SafeHTTPConnection


class _SafeHTTPSPool(HTTPSConnectionPool):
    ConnectionCls = _SafeHTTPSConnection


class _SafeAdapter(HTTPAdapter):
    def init_poolmanager(self, *args, **kwargs):
        super().init_poolmanager(*args, **kwargs)
        self.poolmanager.pool_classes_by_scheme = {"http": _SafeHTTPPool, "https": _SafeHTTPSPool}


def _new_session() -> requests.Session:
    session = requests.Session()
    session.trust_env = False  # ignore proxy env vars and ~/.netrc
    adapter = _SafeAdapter(max_retries=0, pool_connections=1, pool_maxsize=1)
    session.mount("http://", adapter)
    session.mount("https://", adapter)
    return session


# --- Request preparation ----------------------------------------------------
def _prepare(headers, body, method):
    out = {"User-Agent": USER_AGENT, "Accept": "application/json, */*;q=0.8"}
    headers = headers or {}
    if len(headers) > 20:
        raise InvalidRequest("Too many headers (maximum 20).")
    for name, value in headers.items():
        if not isinstance(name, str) or not isinstance(value, str):
            raise InvalidRequest("Header names and values must be text.")
        name, value = name.strip(), value.strip()
        if not _HEADER_NAME_RE.match(name):
            raise InvalidRequest(f"Invalid header name: {name[:30]}")
        if name.lower() in FORBIDDEN_HEADERS:
            raise InvalidRequest(f"The {name} header is set automatically and cannot be changed.")
        if len(value) > 4096 or any(c in value for c in "\r\n\x00"):
            raise InvalidRequest(f"Invalid value for the {name} header.")
        out[name] = value

    data = None
    if body and method in ("POST", "PUT"):
        raw = body.encode("utf-8")
        if len(raw) > MAX_BODY_BYTES:
            raise InvalidRequest("The request body is too large (maximum 100 KB).")
        data = raw
        if not any(k.lower() == "content-type" for k in out):
            try:
                json.loads(body)
                out["Content-Type"] = "application/json"
            except ValueError:
                out["Content-Type"] = "text/plain; charset=utf-8"
    return out, data


def _origin(url: str) -> tuple:
    parts = urlsplit(url)
    return (parts.scheme.lower(), (parts.hostname or "").lower(), parts.port)


def _decode(raw: bytes, headers) -> str:
    encoding = get_encoding_from_headers(headers) or "utf-8"
    try:
        return raw.decode(encoding, errors="replace")
    except LookupError:
        return raw.decode("utf-8", errors="replace")


def _classify_connection_error(exc: Exception) -> str:
    text = str(exc).lower()
    if any(s in text for s in (
        "name or service not known", "nodename nor servname", "temporary failure in name resolution",
        "getaddrinfo failed", "no address associated",
    )):
        return "dns_error"
    if "refused" in text:
        return "connection_refused"
    if "timed out" in text:
        return "timeout"
    return "network_error"


# --- Diagnosis ---------------------------------------------------------------
def build_observations(r: dict) -> list[dict]:
    obs: list[dict] = []

    def add(level: str, message: str) -> None:
        obs.append({"level": level, "message": message})

    if r["error_type"]:
        add("error", r["error_message"])

    sc = r["status_code"]
    if sc is not None:
        if 200 <= sc < 300:
            add("ok", f"The request succeeded (HTTP {sc}).")
        elif 300 <= sc < 400:
            add("warning", f"The server answered with a redirect (HTTP {sc}) that could not be followed any further.")
        elif sc == 401:
            add("error", "Authentication failed (401 Unauthorized). The credentials are missing, invalid or expired. Check your Authorization header or API key.")
        elif sc == 403:
            add("error", "Access forbidden (403). Your credentials may lack permission, or the server blocks this client.")
        elif sc == 404:
            add("error", "Not found (404). Check the URL path, the API version prefix and any IDs in the URL.")
        elif sc == 405:
            add("error", f"Method not allowed (405). This endpoint does not accept {r['method']}. Check the API documentation.")
        elif sc in (400, 415, 422):
            add("error", f"The server rejected the request (HTTP {sc}). Check the request body, its format and the Content-Type header.")
        elif sc == 429:
            add("warning", "Rate limited (429). Too many requests were sent; wait and retry more slowly.")
        elif 400 <= sc < 500:
            add("error", f"Client error (HTTP {sc}). The server rejected the request.")
        elif sc >= 500:
            add("error", f"Server error (HTTP {sc}). The problem is on the server side; check its logs.")

        ms = r["response_time_ms"]
        if ms is not None:
            if ms > VERY_SLOW_MS:
                add("error", f"Very slow response ({ms:.0f} ms). Look for slow database queries or overloaded servers.")
            elif ms > SLOW_MS:
                add("warning", f"Slow response ({ms:.0f} ms). Most APIs should answer in under 1 second.")
            else:
                add("ok", f"Good response time ({ms:.0f} ms).")

        if r["json_valid"] is True:
            add("ok", "The response body is valid JSON.")
        elif r["json_valid"] is False:
            add("warning", "The response looks like JSON but cannot be parsed. Look for trailing commas, an HTML error page, or truncated output.")
        elif r["truncated"]:
            add("info", "The response is larger than 1 MB, so only the first part was inspected.")

    if r["redirects"]:
        add("info", f"Followed {len(r['redirects'])} redirect(s).")
    if r["url"].strip().lower().startswith("http://"):
        add("warning", "This endpoint uses http://, so traffic is not encrypted. Use https:// for anything with credentials.")
    return obs


# --- Main entry point ----------------------------------------------------------
def run_api_test(url, method="GET", headers=None, body=None, timeout_seconds=10) -> dict:
    method = (method or "GET").upper()
    result = {
        "url": (url or "").strip(), "method": method, "ok": False, "status_code": None,
        "reason": None, "response_time_ms": None, "response_size_bytes": None,
        "truncated": False, "content_type": None, "json_valid": None,
        "body_preview": None, "redirects": [], "error_type": None,
        "error_message": None, "observations": [],
    }
    timeout_seconds = max(1, min(int(timeout_seconds), 15))
    start = time.perf_counter()
    session = _new_session()

    try:
        if method not in ALLOWED_METHODS:
            raise InvalidRequest("The method must be GET, POST, PUT or DELETE.")
        req_headers, data = _prepare(headers, body, method)
        deadline = start + timeout_seconds
        current_url, current_method = result["url"], method
        origin = _origin(current_url)

        for hop in range(MAX_REDIRECTS + 1):
            validate_url(current_url)
            remaining = deadline - time.perf_counter()
            if remaining <= 0:
                raise requests.exceptions.Timeout()
            resp = session.request(
                current_method, current_url, headers=req_headers, data=data,
                allow_redirects=False, stream=True, timeout=(min(remaining, 5), remaining),
            )
            location = resp.headers.get("Location")
            if resp.status_code in REDIRECT_CODES and location and hop < MAX_REDIRECTS:
                resp.close()
                next_url = urljoin(current_url, location)
                result["redirects"].append(next_url)
                if resp.status_code in (301, 302, 303) and current_method != "GET":
                    current_method, data = "GET", None
                    req_headers = {k: v for k, v in req_headers.items() if k.lower() != "content-type"}
                if _origin(next_url) != origin:  # never leak credentials to another site
                    req_headers = {k: v for k, v in req_headers.items()
                                   if k.lower() in ("accept", "user-agent")}
                current_url = next_url
                continue
            break

        chunks, size, truncated = [], 0, False
        for chunk in resp.iter_content(chunk_size=8192):
            if not chunk:
                continue
            if size + len(chunk) > MAX_RESPONSE_BYTES:
                chunks.append(chunk[: MAX_RESPONSE_BYTES - size])
                size, truncated = MAX_RESPONSE_BYTES, True
                break
            chunks.append(chunk)
            size += len(chunk)
            if time.perf_counter() > deadline:
                raise requests.exceptions.Timeout()
        resp.close()

        text = _decode(b"".join(chunks), resp.headers)
        content_type = resp.headers.get("Content-Type")
        json_valid = None
        if "json" in (content_type or "").lower() or text.lstrip()[:1] in ("{", "["):
            if not truncated:
                try:
                    json.loads(text)
                    json_valid = True
                except ValueError:
                    json_valid = False

        result.update(
            ok=200 <= resp.status_code < 300, status_code=resp.status_code, reason=resp.reason,
            response_size_bytes=size, truncated=truncated, content_type=content_type,
            json_valid=json_valid, body_preview=text[:PREVIEW_CHARS],
        )
    except InvalidRequest as exc:
        result.update(error_type="invalid_request", error_message=str(exc))
    except BlockedTargetError as exc:
        result.update(error_type="blocked", error_message=str(exc))
    except DNSResolutionError:
        result.update(error_type="dns_error", error_message=ERROR_MESSAGES["dns_error"])
    except requests.exceptions.Timeout:
        result.update(error_type="timeout", error_message=ERROR_MESSAGES["timeout"])
    except requests.exceptions.SSLError:
        result.update(error_type="ssl_error", error_message=ERROR_MESSAGES["ssl_error"])
    except requests.exceptions.ConnectionError as exc:
        kind = _classify_connection_error(exc)
        result.update(error_type=kind, error_message=ERROR_MESSAGES[kind])
    except requests.exceptions.InvalidURL:
        result.update(error_type="invalid_request", error_message="The URL is not valid.")
    except requests.exceptions.RequestException:
        result.update(error_type="network_error", error_message=ERROR_MESSAGES["network_error"])
    finally:
        session.close()

    result["response_time_ms"] = round((time.perf_counter() - start) * 1000, 1)
    result["observations"] = build_observations(result)
    return result
