"""Tiny in-memory sliding-window rate limiter.

Good enough for a single-process MVP. For several server processes or
instances, replace it with Redis (or your host's rate limiting)."""
import threading
import time
from collections import defaultdict, deque


class RateLimitExceeded(Exception):
    def __init__(self, retry_after: int):
        super().__init__(f"Rate limit exceeded. Try again in {retry_after} seconds.")
        self.retry_after = retry_after


_lock = threading.Lock()
_hits: dict[str, deque] = defaultdict(deque)


def check_rate_limit(key: str, limit: int, window_seconds: int) -> None:
    now = time.monotonic()
    with _lock:
        hits = _hits[key]
        while hits and now - hits[0] > window_seconds:
            hits.popleft()
        if len(hits) >= limit:
            raise RateLimitExceeded(int(window_seconds - (now - hits[0])) + 1)
        hits.append(now)


def reset() -> None:
    """Used by tests."""
    with _lock:
        _hits.clear()
