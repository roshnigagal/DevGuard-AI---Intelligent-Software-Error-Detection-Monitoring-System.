"""SSRF protection helpers.

The API tester makes requests to URLs chosen by users. Without protection a
user could make OUR server call internal services (localhost, cloud metadata at
169.254.169.254, private networks). We therefore only allow public addresses.
"""
import ipaddress
import socket
from urllib.parse import urlsplit

MAX_URL_LENGTH = 2048
ALLOWED_SCHEMES = {"http", "https"}
_NAT64 = ipaddress.ip_network("64:ff9b::/96")


class BlockedTargetError(ValueError):
    """The URL points somewhere we refuse to connect to."""


class DNSResolutionError(ValueError):
    """The host name could not be resolved."""


def is_public_ip(ip_str: str) -> bool:
    """True only for globally routable unicast addresses."""
    try:
        ip = ipaddress.ip_address(ip_str.split("%")[0])
    except ValueError:
        return False

    if isinstance(ip, ipaddress.IPv6Address):
        # ::ffff:127.0.0.1 and friends must be judged by the IPv4 address inside
        if ip.ipv4_mapped is not None:
            return is_public_ip(str(ip.ipv4_mapped))
        if ip in _NAT64:
            return is_public_ip(str(ipaddress.IPv4Address(int(ip) & 0xFFFFFFFF)))
        if ip.sixtofour is not None:
            return is_public_ip(str(ip.sixtofour))
        if ip.teredo is not None:
            return False
    return ip.is_global and not ip.is_multicast


def validate_url(url: str) -> tuple[str, int]:
    """Validate a user-supplied URL and return (host, port).

    Raises BlockedTargetError for anything unsafe and DNSResolutionError when
    the name does not resolve. Every resolved address must be public.
    """
    url = (url or "").strip()
    if not url:
        raise BlockedTargetError("Enter a URL to test.")
    if len(url) > MAX_URL_LENGTH:
        raise BlockedTargetError("The URL is too long.")

    try:
        parts = urlsplit(url)
        port = parts.port
    except ValueError:
        raise BlockedTargetError("The URL is not valid.") from None

    scheme = parts.scheme.lower()
    if scheme not in ALLOWED_SCHEMES:
        raise BlockedTargetError("Only http:// and https:// URLs are allowed.")
    if parts.username or parts.password:
        raise BlockedTargetError(
            "URLs with embedded credentials are not allowed. Use the headers field instead."
        )

    host = (parts.hostname or "").rstrip(".")
    if not host:
        raise BlockedTargetError("The URL has no host name.")
    lowered = host.lower()
    if lowered == "localhost" or lowered.endswith((".localhost", ".local", ".internal")):
        raise BlockedTargetError("Local and internal addresses cannot be tested.")

    port = port or (443 if scheme == "https" else 80)
    if not 0 < port < 65536:
        raise BlockedTargetError("The port number is not valid.")

    try:
        infos = socket.getaddrinfo(host, port, type=socket.SOCK_STREAM)
    except socket.gaierror:
        raise DNSResolutionError(host) from None
    except UnicodeError:
        raise BlockedTargetError("The host name is not valid.") from None

    for info in infos:
        address = info[4][0]
        if not is_public_ip(address):
            raise BlockedTargetError(
                "That address points to a private or reserved network, "
                "so the request was blocked."
            )
    return host, port
