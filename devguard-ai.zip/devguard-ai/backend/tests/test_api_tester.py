import json
import socket
import threading
import time
import unittest
from http.server import BaseHTTPRequestHandler, HTTPServer
from unittest import mock

from app.services import api_tester
from app.utils.ssrf import BlockedTargetError


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def _send(self, status, body=b"", ctype="application/json", extra=None):
        self.send_response(status)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        p = self.path
        if p == "/ok":
            self._send(200, b'{"hello": "world"}')
        elif p == "/badjson":
            self._send(200, b'{"hello": "world",}')
        elif p == "/html":
            self._send(200, b"<html></html>", "text/html")
        elif p == "/401":
            self._send(401, b'{"error": "no"}')
        elif p == "/404":
            self._send(404, b"{}")
        elif p == "/500":
            self._send(500, b'{"error": "boom"}')
        elif p == "/redirect":
            self._send(302, b"", extra={"Location": "/ok"})
        elif p == "/loop":
            self._send(302, b"", extra={"Location": "/loop"})
        elif p == "/slow":
            time.sleep(2)
            try:
                self._send(200, b"{}")
            except (BrokenPipeError, ConnectionResetError):
                pass  # the client already timed out and hung up, as intended
        elif p == "/big":
            self._send(200, b"x" * 1_500_000, "text/plain")
        elif p == "/echo-auth":
            self._send(200, json.dumps({"auth": self.headers.get("Authorization")}).encode())
        else:
            self._send(404, b"{}")

    def do_POST(self):
        length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(length)
        self._send(201, json.dumps({"len": len(body), "ctype": self.headers.get("Content-Type")}).encode())

    do_PUT = do_POST

    def do_DELETE(self):
        self._send(200, b'{"deleted": true}')


class ApiTesterTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = HTTPServer(("127.0.0.1", 0), Handler)
        cls.port = cls.server.server_address[1]
        threading.Thread(target=cls.server.serve_forever, daemon=True).start()
        cls.base = f"http://127.0.0.1:{cls.port}"

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()

    def run_test(self, path, **kw):
        # Loopback is blocked in real use, so switch both SSRF layers off for these functional tests.
        with mock.patch.object(api_tester, "validate_url", return_value=("127.0.0.1", self.port)), \
             mock.patch.object(api_tester, "is_public_ip", return_value=True):
            return api_tester.run_api_test(self.base + path, **kw)

    def levels(self, r):
        return {o["level"] for o in r["observations"]}

    # --- diagnosis -------------------------------------------------------
    def test_success_with_valid_json(self):
        r = self.run_test("/ok")
        self.assertTrue(r["ok"])
        self.assertEqual(r["status_code"], 200)
        self.assertIs(r["json_valid"], True)
        self.assertIsNone(r["error_type"])
        self.assertIn("ok", self.levels(r))
        self.assertIsInstance(r["response_time_ms"], float)

    def test_invalid_json_is_detected(self):
        r = self.run_test("/badjson")
        self.assertIs(r["json_valid"], False)
        self.assertIn("warning", self.levels(r))

    def test_html_is_not_flagged_as_json(self):
        self.assertIsNone(self.run_test("/html")["json_valid"])

    def test_authentication_failure_is_explained(self):
        r = self.run_test("/401")
        self.assertFalse(r["ok"])
        self.assertEqual(r["status_code"], 401)
        self.assertTrue(any("Authentication failed" in o["message"] for o in r["observations"]))

    def test_404_and_500(self):
        self.assertEqual(self.run_test("/404")["status_code"], 404)
        r = self.run_test("/500")
        self.assertTrue(any("Server error" in o["message"] for o in r["observations"]))

    def test_redirect_is_followed(self):
        r = self.run_test("/redirect")
        self.assertEqual(r["status_code"], 200)
        self.assertEqual(len(r["redirects"]), 1)

    def test_redirect_loop_stops(self):
        r = self.run_test("/loop")
        self.assertEqual(r["status_code"], 302)
        self.assertEqual(len(r["redirects"]), api_tester.MAX_REDIRECTS)

    def test_timeout(self):
        r = self.run_test("/slow", timeout_seconds=1)
        self.assertEqual(r["error_type"], "timeout")
        self.assertIsNone(r["status_code"])

    def test_connection_refused(self):
        s = socket.socket()
        s.bind(("127.0.0.1", 0))
        port = s.getsockname()[1]
        s.close()
        with mock.patch.object(api_tester, "validate_url", return_value=("127.0.0.1", port)), \
             mock.patch.object(api_tester, "is_public_ip", return_value=True):
            r = api_tester.run_api_test(f"http://127.0.0.1:{port}/")
        self.assertEqual(r["error_type"], "connection_refused")

    def test_response_size_is_capped(self):
        r = self.run_test("/big")
        self.assertTrue(r["truncated"])
        self.assertEqual(r["response_size_bytes"], api_tester.MAX_RESPONSE_BYTES)
        self.assertLessEqual(len(r["body_preview"]), api_tester.PREVIEW_CHARS)

    # --- methods, headers, bodies ------------------------------------------
    def test_post_sets_json_content_type(self):
        r = self.run_test("/x", method="POST", body='{"a": 1}')
        body = json.loads(r["body_preview"])
        self.assertEqual(r["status_code"], 201)
        self.assertEqual(body["ctype"], "application/json")
        self.assertEqual(body["len"], 8)

    def test_put_and_delete(self):
        self.assertEqual(self.run_test("/x", method="PUT", body="hi")["status_code"], 201)
        self.assertEqual(self.run_test("/x", method="DELETE")["status_code"], 200)

    def test_auth_header_is_sent(self):
        r = self.run_test("/echo-auth", headers={"Authorization": "Bearer abc"})
        self.assertEqual(json.loads(r["body_preview"])["auth"], "Bearer abc")

    def test_invalid_inputs_are_rejected(self):
        cases = [
            dict(method="PATCH"),
            dict(headers={"Host": "evil.com"}),
            dict(headers={"X-Test": "a\r\nInjected: 1"}),
            dict(headers={"bad name": "v"}),
            dict(headers={f"X-{i}": "v" for i in range(25)}),
            dict(method="POST", body="x" * 200_000),
        ]
        for kw in cases:
            with self.subTest(kw=str(kw)[:50]):
                r = self.run_test("/ok", **kw)
                self.assertEqual(r["error_type"], "invalid_request")

    # --- SSRF -----------------------------------------------------------------
    def test_loopback_is_blocked_by_url_validation(self):
        r = api_tester.run_api_test(self.base + "/ok")
        self.assertEqual(r["error_type"], "blocked")
        self.assertIsNone(r["status_code"])

    def test_metadata_endpoint_is_blocked(self):
        r = api_tester.run_api_test("http://169.254.169.254/latest/meta-data/")
        self.assertEqual(r["error_type"], "blocked")

    def test_connect_time_check_blocks_dns_rebinding(self):
        """URL validation is fooled (as DNS rebinding would), but the real peer IP is private."""
        with mock.patch.object(api_tester, "validate_url", return_value=("example.com", self.port)):
            r = api_tester.run_api_test(self.base + "/ok")
        self.assertEqual(r["error_type"], "blocked")
        self.assertIsNone(r["status_code"])

    def test_redirect_to_internal_address_is_blocked(self):
        calls = []

        def fake_validate(url):
            calls.append(url)
            if "169.254" in url:
                raise BlockedTargetError("blocked")
            return ("127.0.0.1", self.port)

        class Redirector(BaseHTTPRequestHandler):
            def log_message(self, *a):
                pass

            def do_GET(self):
                self.send_response(302)
                self.send_header("Location", "http://169.254.169.254/latest/meta-data/")
                self.send_header("Content-Length", "0")
                self.end_headers()

        srv = HTTPServer(("127.0.0.1", 0), Redirector)
        threading.Thread(target=srv.serve_forever, daemon=True).start()
        try:
            with mock.patch.object(api_tester, "validate_url", side_effect=fake_validate), \
                 mock.patch.object(api_tester, "is_public_ip", return_value=True):
                r = api_tester.run_api_test(f"http://127.0.0.1:{srv.server_address[1]}/")
        finally:
            srv.shutdown()
            srv.server_close()
        self.assertEqual(r["error_type"], "blocked")
        self.assertTrue(any("169.254" in c for c in calls))

    def test_credentials_not_forwarded_across_origins(self):
        seen = {}

        class Target(BaseHTTPRequestHandler):
            def log_message(self, *a):
                pass

            def do_GET(self):
                seen["auth"] = self.headers.get("Authorization")
                self.send_response(200)
                self.send_header("Content-Length", "2")
                self.end_headers()
                self.wfile.write(b"{}")

        target = HTTPServer(("127.0.0.1", 0), Target)
        # 'localhost' vs '127.0.0.1' is a different origin even though same machine
        tport = target.server_address[1]

        class Redirector(BaseHTTPRequestHandler):
            def log_message(self, *a):
                pass

            def do_GET(self):
                self.send_response(302)
                self.send_header("Location", f"http://localhost:{tport}/")
                self.send_header("Content-Length", "0")
                self.end_headers()

        redirector = HTTPServer(("127.0.0.1", 0), Redirector)
        for s in (target, redirector):
            threading.Thread(target=s.serve_forever, daemon=True).start()
        try:
            with mock.patch.object(api_tester, "validate_url", return_value=("127.0.0.1", 0)), \
                 mock.patch.object(api_tester, "is_public_ip", return_value=True):
                r = api_tester.run_api_test(
                    f"http://127.0.0.1:{redirector.server_address[1]}/",
                    headers={"Authorization": "Bearer secret"},
                )
        finally:
            for s in (target, redirector):
                s.shutdown()
                s.server_close()
        self.assertEqual(r["status_code"], 200)
        self.assertIsNone(seen["auth"])


if __name__ == "__main__":
    unittest.main()
