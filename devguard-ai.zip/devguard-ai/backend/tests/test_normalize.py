import json
import os
import tempfile
import unittest

from app.scanners import normalize as N

ROOT = "/tmp/proj"


class ParserTests(unittest.TestCase):
    def test_ruff(self):
        raw = json.dumps([
            {"code": "F401", "message": "`os` imported but unused", "filename": f"{ROOT}/app/a.py",
             "location": {"row": 1, "column": 8}, "url": "https://docs.astral.sh/ruff/rules/unused-import"},
            {"code": "F821", "message": "Undefined name `x`", "filename": f"{ROOT}/b.py",
             "location": {"row": 7, "column": 1}},
            {"code": None, "message": "SyntaxError: Expected ':'", "filename": f"{ROOT}/c.py",
             "location": {"row": 3, "column": 9}},
            {"code": "B006", "message": "Do not use mutable default", "filename": f"{ROOT}/d.py",
             "location": {"row": 2, "column": 1}},
        ])
        f = N.parse_ruff(raw, ROOT)
        self.assertEqual([x["severity"] for x in f], ["low", "high", "high", "medium"])
        self.assertEqual(f[0]["file"], "app/a.py")
        self.assertEqual(f[0]["category"], "quality")
        self.assertEqual(f[2]["rule_id"], "syntax-error")

    def test_bandit(self):
        raw = json.dumps({"errors": [], "results": [{
            "filename": f"{ROOT}/db.py", "line_number": 25, "col_offset": 4, "test_id": "B608",
            "issue_severity": "MEDIUM", "issue_text": "Possible SQL injection",
            "issue_cwe": {"id": 89}, "more_info": "https://bandit.readthedocs.io/"}]})
        f = N.parse_bandit(raw, ROOT)[0]
        self.assertEqual((f["tool"], f["severity"], f["category"], f["line"]), ("bandit", "medium", "security", 25))
        self.assertIn("CWE-89", f["message"])

    def test_eslint(self):
        raw = json.dumps([{"filePath": f"{ROOT}/src/x.js", "messages": [
            {"ruleId": "no-undef", "severity": 2, "message": "'foo' is not defined.", "line": 4, "column": 1},
            {"ruleId": "no-unused-vars", "severity": 1, "message": "unused", "line": 1, "column": 5},
            {"ruleId": None, "fatal": True, "severity": 2, "message": "Parsing error", "line": 9, "column": 2},
            {"ruleId": "no-eval", "severity": 2, "message": "eval can be harmful.", "line": 3, "column": 1},
        ]}])
        f = N.parse_eslint(raw, ROOT)
        self.assertEqual([x["severity"] for x in f], ["medium", "low", "high", "high"])
        self.assertEqual(f[2]["rule_id"], "parse-error")
        self.assertEqual(f[3]["category"], "security")
        self.assertEqual(f[0]["file"], "src/x.js")

    def test_bad_output_raises(self):
        for fn in (N.parse_ruff, N.parse_bandit, N.parse_eslint):
            with self.assertRaises(N.ToolOutputError):
                fn("", ROOT)
            with self.assertRaises(N.ToolOutputError):
                fn("not json", ROOT)
        with self.assertRaises(N.ToolOutputError):
            N.parse_bandit("[]", ROOT)

    def test_summary(self):
        s = N.build_summary([
            {"severity": "high", "tool": "ruff", "category": "bug"},
            {"severity": "high", "tool": "bandit", "category": "security"},
            {"severity": "low", "tool": "ruff", "category": "quality"},
        ])
        self.assertEqual(s["total"], 3)
        self.assertEqual(s["by_severity"]["high"], 2)
        self.assertEqual(s["by_severity"]["critical"], 0)
        self.assertEqual(s["by_tool"], {"ruff": 2, "bandit": 1})

    def test_read_code_line_is_confined_to_root(self):
        with tempfile.TemporaryDirectory() as d:
            with open(os.path.join(d, "a.py"), "w") as fh:
                fh.write("one\ntwo\nthree\n")
            self.assertEqual(N.read_code_line(d, "a.py", 2), "two")
            self.assertIsNone(N.read_code_line(d, "a.py", 99))
            self.assertIsNone(N.read_code_line(d, "../../etc/passwd", 1))
            self.assertIsNone(N.read_code_line(d, "a.py", None))


if __name__ == "__main__":
    unittest.main()
