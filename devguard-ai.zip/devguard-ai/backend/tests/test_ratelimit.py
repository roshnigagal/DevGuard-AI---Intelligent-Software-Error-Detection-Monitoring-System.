import unittest

from app.utils import ratelimit


class RateLimitTests(unittest.TestCase):
    def setUp(self):
        ratelimit.reset()

    def test_allows_up_to_limit_then_blocks(self):
        for _ in range(3):
            ratelimit.check_rate_limit("u1", 3, 60)
        with self.assertRaises(ratelimit.RateLimitExceeded) as ctx:
            ratelimit.check_rate_limit("u1", 3, 60)
        self.assertGreaterEqual(ctx.exception.retry_after, 1)

    def test_keys_are_independent(self):
        ratelimit.check_rate_limit("a", 1, 60)
        ratelimit.check_rate_limit("b", 1, 60)


if __name__ == "__main__":
    unittest.main()
