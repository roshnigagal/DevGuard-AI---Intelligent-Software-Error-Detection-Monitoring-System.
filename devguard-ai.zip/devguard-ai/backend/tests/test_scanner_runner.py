import os
import tempfile
import unittest

from app.scanners.runner import detect_languages, scan_directory


class RunnerTests(unittest.TestCase):
    def make_project(self):
        d = tempfile.TemporaryDirectory()
        self.addCleanup(d.cleanup)
        os.makedirs(os.path.join(d.name, "src"))
        for name, text in {
            "app.py": "import os\n\ndef f(:\n    pass\n",
            "src/main.js": "const a = 1\nfoo()\n",
            "src/types.ts": "export const x: number = 1;\n",
            "README.md": "# hi",
        }.items():
            with open(os.path.join(d.name, name), "w") as fh:
                fh.write(text)
        return d.name

    def test_detect_languages(self):
        root = self.make_project()
        self.assertEqual(detect_languages(root), {"python": 1, "javascript": 1, "typescript": 1})

    def test_scan_directory_returns_complete_structure_even_when_tools_are_missing(self):
        root = self.make_project()
        result = scan_directory(root)
        self.assertEqual(set(result), {"findings", "summary", "tools", "languages"})
        self.assertEqual({t["name"] for t in result["tools"]}, {"ruff", "bandit", "eslint"})
        for tool in result["tools"]:
            self.assertIn(tool["status"], {"ok", "skipped", "error", "timeout"})
        self.assertTrue(any("TypeScript" in n for n in result["summary"]["notes"]))
        self.assertEqual(result["summary"]["files_scanned"], 2)
        for i, f in enumerate(result["findings"]):
            self.assertEqual(f["id"], i)  # ids are positions, used by the AI step

    def test_empty_of_supported_code(self):
        with tempfile.TemporaryDirectory() as d:
            with open(os.path.join(d, "notes.txt"), "w") as fh:
                fh.write("hello")
            result = scan_directory(d)
        self.assertEqual(result["summary"]["total"], 0)
        self.assertTrue(any("No Python or JavaScript" in n for n in result["summary"]["notes"]))


if __name__ == "__main__":
    unittest.main()
