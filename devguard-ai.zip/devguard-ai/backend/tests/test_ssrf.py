import unittest

from app.utils.ssrf import BlockedTargetError, DNSResolutionError, is_public_ip, validate_url


class IsPublicIpTests(unittest.TestCase):
    def test_blocks_private_and_special_ranges(self):
        for ip in [
            "127.0.0.1", "10.0.0.5", "172.16.3.4", "192.168.1.1", "169.254.169.254",
            "100.64.0.1", "0.0.0.0", "224.0.0.1", "255.255.255.255", "::1", "fe80::1",
            "fc00::1", "::ffff:127.0.0.1", "::ffff:10.0.0.1", "64:ff9b::7f00:1", "2002:7f00:1::1",
            "not-an-ip",
        ]:
            with self.subTest(ip=ip):
                self.assertFalse(is_public_ip(ip))

    def test_allows_public_addresses(self):
        for ip in ["8.8.8.8", "93.184.216.34", "1.1.1.1", "2606:4700:4700::1111"]:
            with self.subTest(ip=ip):
                self.assertTrue(is_public_ip(ip))


class ValidateUrlTests(unittest.TestCase):
    def assertBlocked(self, url):
        with self.assertRaises(BlockedTargetError, msg=url):
            validate_url(url)

    def test_blocks_dangerous_urls(self):
        for url in [
            "", "   ", "file:///etc/passwd", "ftp://example.com/x", "gopher://example.com",
            "http://127.0.0.1/", "http://127.0.0.1:8000/admin", "http://localhost/", "http://LOCALHOST:3000",
            "http://app.localhost/", "http://printer.local/", "http://db.internal/",
            "http://169.254.169.254/latest/meta-data/", "http://[::1]/", "http://[::ffff:127.0.0.1]/",
            "http://10.1.2.3/", "http://192.168.0.1/", "http://0.0.0.0/",
            "http://2130706433/",            # decimal form of 127.0.0.1
            "http://0x7f.0.0.1/",            # hex form
            "http://user:pass@93.184.216.34/",
            "http:///nohost", "http://93.184.216.34:99999/", "http://" + "a" * 3000 + ".com",
        ]:
            with self.subTest(url=url[:60]):
                try:
                    validate_url(url)
                except (BlockedTargetError, DNSResolutionError):
                    continue  # DNS failure for odd forms is also a refusal
                self.fail(f"{url[:60]} was allowed")

    def test_allows_public_ip_literals(self):
        self.assertEqual(validate_url("https://93.184.216.34/path"), ("93.184.216.34", 443))
        self.assertEqual(validate_url("http://8.8.8.8:8080"), ("8.8.8.8", 8080))

    def test_unresolvable_name_is_a_dns_error(self):
        with self.assertRaises(DNSResolutionError):
            validate_url("http://this-domain-does-not-exist.invalid/")


if __name__ == "__main__":
    unittest.main()
