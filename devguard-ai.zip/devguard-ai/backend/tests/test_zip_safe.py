import io
import os
import stat
import tempfile
import unittest
import zipfile

from app.scanners.zip_safe import UnsafeZipError, ZipLimits, safe_extract


def make_zip(entries, path):
    """entries: list of (name, bytes) or (ZipInfo, bytes)."""
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as zf:
        for name, data in entries:
            zf.writestr(name, data)
    return path


class ZipSafeTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.zip_path = os.path.join(self.tmp.name, "up.zip")
        self.dest = os.path.join(self.tmp.name, "out")

    def tearDown(self):
        self.tmp.cleanup()

    def test_extracts_normal_project(self):
        make_zip([("app/main.py", b"print('hi')\n"), ("README.md", b"# hi")], self.zip_path)
        result = safe_extract(self.zip_path, self.dest)
        self.assertEqual(result.files_extracted, 2)
        self.assertTrue(os.path.isfile(os.path.join(self.dest, "app", "main.py")))

    def test_rejects_path_traversal(self):
        make_zip([("../evil.py", b"x"), ("ok.py", b"y")], self.zip_path)
        with self.assertRaises(UnsafeZipError):
            safe_extract(self.zip_path, self.dest)
        self.assertFalse(os.path.exists(os.path.join(self.tmp.name, "evil.py")))

    def test_rejects_nested_traversal_and_absolute_paths(self):
        for name in ("a/../../evil.py", "/etc/evil.py", "C:/evil.py", "..\\evil.py"):
            with self.subTest(name=name):
                make_zip([(name, b"x")], self.zip_path)
                with self.assertRaises(UnsafeZipError):
                    safe_extract(self.zip_path, self.dest)

    def test_skips_symlinks(self):
        info = zipfile.ZipInfo("link.py")
        info.external_attr = (stat.S_IFLNK | 0o777) << 16
        with zipfile.ZipFile(self.zip_path, "w") as zf:
            zf.writestr(info, "/etc/passwd")
            zf.writestr("real.py", "x = 1\n")
        result = safe_extract(self.zip_path, self.dest)
        self.assertEqual(result.files_extracted, 1)
        self.assertEqual(result.files_skipped, 1)
        self.assertFalse(os.path.lexists(os.path.join(self.dest, "link.py")))

    def test_skips_node_modules_and_git(self):
        make_zip([("src/a.js", b"1"), ("node_modules/x/i.js", b"2"), (".git/config", b"3")], self.zip_path)
        result = safe_extract(self.zip_path, self.dest)
        self.assertEqual(result.files_extracted, 1)
        self.assertEqual(result.files_skipped, 2)

    def test_rejects_too_many_files(self):
        make_zip([(f"f{i}.py", b"x") for i in range(6)], self.zip_path)
        with self.assertRaises(UnsafeZipError):
            safe_extract(self.zip_path, self.dest, ZipLimits(max_files=5))

    def test_rejects_oversized_file(self):
        make_zip([("big.txt", os.urandom(2048))], self.zip_path)
        with self.assertRaises(UnsafeZipError):
            safe_extract(self.zip_path, self.dest, ZipLimits(max_file_bytes=1024))

    def test_rejects_zip_bomb_by_ratio(self):
        make_zip([("zeros.txt", b"\0" * (4 * 1024 * 1024))], self.zip_path)
        with self.assertRaises(UnsafeZipError):
            safe_extract(self.zip_path, self.dest)

    def test_rejects_when_total_exceeds_limit(self):
        make_zip([(f"f{i}.bin", os.urandom(4000)) for i in range(5)], self.zip_path)
        with self.assertRaises(UnsafeZipError):
            safe_extract(self.zip_path, self.dest, ZipLimits(max_total_bytes=10_000))

    def test_rejects_non_zip(self):
        with open(self.zip_path, "wb") as fh:
            fh.write(b"this is not a zip file")
        with self.assertRaises(UnsafeZipError):
            safe_extract(self.zip_path, self.dest)

    def test_rejects_corrupted_zip(self):
        make_zip([("a.py", b"print(1)" * 100)], self.zip_path)
        with open(self.zip_path, "r+b") as fh:
            fh.truncate(os.path.getsize(self.zip_path) - 30)
        with self.assertRaises(UnsafeZipError):
            safe_extract(self.zip_path, self.dest)

    def test_rejects_empty_archive_contents(self):
        make_zip([("node_modules/a.js", b"x")], self.zip_path)
        with self.assertRaises(UnsafeZipError):
            safe_extract(self.zip_path, self.dest)


if __name__ == "__main__":
    unittest.main()
