"""Small helpers used by start.bat (batch files are poor at quoting, so the checks live here).

  check.py busy PORT                exit 0 if something is already listening on PORT
  check.py wait-port PORT SECONDS   exit 0 once PORT accepts connections
  check.py wait-http URL SECONDS    exit 0 once URL answers with HTTP 200
  check.py health URL               print setup warnings from the API health endpoint
"""
import json
import socket
import sys
import time
import urllib.request


# Ignore any system proxy settings: these checks only talk to localhost.
OPENER = urllib.request.build_opener(urllib.request.ProxyHandler({}))


def port_open(port: int) -> bool:
    try:
        with socket.create_connection(("127.0.0.1", port), timeout=1):
            return True
    except OSError:
        return False


def http_ok(url: str) -> bool:
    try:
        with OPENER.open(url, timeout=2) as response:
            return response.status == 200
    except Exception:
        return False


def wait_for(check, seconds: float) -> int:
    deadline = time.time() + seconds
    while time.time() < deadline:
        if check():
            return 0
        time.sleep(0.5)
    return 1


def health(url: str) -> int:
    try:
        with OPENER.open(url, timeout=3) as response:
            data = json.load(response)
    except Exception:
        return 0  # not important enough to fail the launch
    if not data.get("auth_configured"):
        print("[WARNING] Supabase is not configured in backend\\.env, so sign-in will fail.")
        print("          Run:  start.bat config")
    if not data.get("ai_configured"):
        print("[WARNING] No Anthropic key in backend\\.env, so 'Explain with Claude' will be unavailable.")
    return 0


def main(argv: list) -> int:
    if len(argv) < 3:
        print(__doc__)
        return 2
    command, target = argv[1], argv[2]
    if command == "busy":
        return 0 if port_open(int(target)) else 1
    if command == "wait-port":
        return wait_for(lambda: port_open(int(target)), float(argv[3]) if len(argv) > 3 else 30)
    if command == "wait-http":
        return wait_for(lambda: http_ok(target), float(argv[3]) if len(argv) > 3 else 30)
    if command == "health":
        return health(target)
    print(__doc__)
    return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv))
