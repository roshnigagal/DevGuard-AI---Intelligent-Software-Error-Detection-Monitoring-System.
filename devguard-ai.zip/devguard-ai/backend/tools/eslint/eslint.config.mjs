// DevGuard AI's own ESLint config. The scanner never loads a config from the
// uploaded project, because ESLint configs are JavaScript and would execute code.
import js from "@eslint/js";
import globals from "globals";

export default [
  js.configs.recommended,
  {
    files: ["**/*.js", "**/*.jsx", "**/*.mjs", "**/*.cjs"],
    languageOptions: {
      ecmaVersion: "latest",
      sourceType: "module",
      globals: { ...globals.browser, ...globals.node },
      parserOptions: { ecmaFeatures: { jsx: true } },
    },
    rules: {
      "no-eval": "error",
      "no-implied-eval": "error",
      "no-new-func": "error",
    },
  },
  { ignores: ["**/node_modules/**", "**/dist/**", "**/build/**", "**/.next/**"] },
];
