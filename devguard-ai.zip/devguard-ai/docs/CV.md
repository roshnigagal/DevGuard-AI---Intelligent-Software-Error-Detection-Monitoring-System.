# DevGuard AI on your CV

Only list what you have actually built, run and understood. Delete any line below that is not true for your version.

## Project entry

**DevGuard AI - AI-Powered Code and API Diagnostics Platform**
Next.js, TypeScript, Tailwind CSS, Python FastAPI, PostgreSQL (Supabase), Anthropic Claude API

- Built a full-stack platform where developers upload a project ZIP and receive a severity-ranked report of bugs, security issues and code-quality problems, produced by Ruff, Bandit and ESLint.
- Integrated the Anthropic Claude API to turn raw scanner output into plain-language explanations, likely root causes and suggested fixes, with strict validation of the model's JSON responses.
- Implemented an API testing module that diagnoses status codes, latency, JSON validity and auth failures, protected against SSRF (public-address allow-listing, connect-time IP verification, re-validated redirects).
- Hardened file handling against malicious uploads: path traversal, zip bombs, symlinks and oversized archives; uploaded code is analysed but never executed.
- Implemented authentication with Supabase Auth (email verification) and server-side token verification; per-user data isolation, rate limiting and saved scan history in PostgreSQL.
- Wrote automated tests for archive safety, SSRF protection, result parsing and AI-response validation.

## Skills line

Full-stack development, Python (FastAPI), TypeScript/React/Next.js, REST API design, PostgreSQL, static analysis, LLM API integration, application security basics, automated testing.

## Interview talking points

- **Why is the AI step on-demand?** Cost control and speed: the scan is free and instant; Claude is only called when the user asks, for the 15 most severe findings, and results are cached in the database.
- **How do you stop prompt injection from uploaded code?** Findings are passed as JSON-escaped data inside delimiters, the system prompt tells Claude to treat them as untrusted, the output must match a strict schema, and the frontend renders everything as text (never HTML).
- **What is SSRF and how did you defend against it?** Users choose URLs the server fetches. The server could be tricked into calling internal services. Defence in depth: scheme and port checks, public-IP-only resolution, a second check on the real peer address after connecting (DNS rebinding), manual redirect following, and no credentials forwarded across sites.
- **What would you do before real production use?** Run scans in a network-less container with CPU/memory limits, move the rate limiter to Redis, add migrations (Alembic), and put a body-size limit on the reverse proxy.
