"use client";

import { FormEvent, useCallback, useEffect, useState } from "react";
import { apiFetch, errorMessage } from "@/lib/api";
import { formatBytes, formatDate } from "@/lib/format";
import type { ApiTestHistoryItem, ApiTestResult, Observation } from "@/lib/types";

const METHODS = ["GET", "POST", "PUT", "DELETE"] as const;
type Method = (typeof METHODS)[number];

const LEVEL_STYLE: Record<Observation["level"], { dot: string; label: string }> = {
  ok: { dot: "bg-ok", label: "Good" },
  info: { dot: "bg-sev-info", label: "Note" },
  warning: { dot: "bg-sev-medium", label: "Warning" },
  error: { dot: "bg-sev-critical", label: "Problem" },
};

function parseHeaders(text: string): { headers: Record<string, string>; error?: string } {
  const headers: Record<string, string> = {};
  const lines = text.split("\n");
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line) continue;
    const colon = line.indexOf(":");
    if (colon < 1) return { headers: {}, error: `Header line ${i + 1} must look like  Name: value` };
    headers[line.slice(0, colon).trim()] = line.slice(colon + 1).trim();
  }
  return { headers };
}

function statusTone(code: number | null, errorType: string | null): string {
  if (errorType || code === null) return "text-sev-critical";
  if (code < 300) return "text-ok";
  if (code < 400) return "text-sev-medium";
  return "text-sev-critical";
}

export default function ApiTesterPage() {
  const [method, setMethod] = useState<Method>("GET");
  const [url, setUrl] = useState("");
  const [headersText, setHeadersText] = useState("");
  const [body, setBody] = useState("");
  const [timeoutSeconds, setTimeoutSeconds] = useState(10);
  const [running, setRunning] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);
  const [result, setResult] = useState<ApiTestResult | null>(null);
  const [history, setHistory] = useState<ApiTestHistoryItem[] | null>(null);

  const loadHistory = useCallback(async () => {
    try {
      setHistory(await apiFetch<ApiTestHistoryItem[]>("/api/api-tests"));
    } catch {
      setHistory([]);
    }
  }, []);

  useEffect(() => {
    loadHistory();
  }, [loadHistory]);

  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setFormError(null);
    const parsed = parseHeaders(headersText);
    if (parsed.error) {
      setFormError(parsed.error);
      return;
    }
    setRunning(true);
    setResult(null);
    try {
      const data = await apiFetch<ApiTestResult>("/api/api-tests", {
        method: "POST",
        body: JSON.stringify({
          url: url.trim(),
          method,
          headers: parsed.headers,
          body: method === "POST" || method === "PUT" ? body : null,
          timeout_seconds: timeoutSeconds,
        }),
      });
      setResult(data);
      loadHistory();
    } catch (err) {
      setFormError(errorMessage(err, "The test could not be run."));
    } finally {
      setRunning(false);
    }
  }

  return (
    <div>
      <h1 className="text-3xl font-bold tracking-tight">API tester</h1>
      <p className="mt-2 max-w-xl text-muted">
        Send one request to a public endpoint and see what came back, and what a failure most likely means.
        Private and local addresses are blocked.
      </p>

      <form onSubmit={onSubmit} className="panel mt-6 space-y-4 px-5 py-5">
        <div className="flex flex-wrap gap-3">
          <div>
            <label htmlFor="method" className="mb-1 block text-sm font-medium">
              Method
            </label>
            <select id="method" value={method} onChange={(e) => setMethod(e.target.value as Method)} className="field !w-28">
              {METHODS.map((m) => (
                <option key={m}>{m}</option>
              ))}
            </select>
          </div>
          <div className="min-w-0 flex-1 basis-72">
            <label htmlFor="url" className="mb-1 block text-sm font-medium">
              URL
            </label>
            <input
              id="url"
              type="url"
              required
              placeholder="https://api.example.com/v1/users"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              className="field font-mono"
            />
          </div>
          <div>
            <label htmlFor="timeout" className="mb-1 block text-sm font-medium">
              Timeout
            </label>
            <select
              id="timeout"
              value={timeoutSeconds}
              onChange={(e) => setTimeoutSeconds(Number(e.target.value))}
              className="field !w-24"
            >
              {[5, 10, 15].map((s) => (
                <option key={s} value={s}>
                  {s} sec
                </option>
              ))}
            </select>
          </div>
        </div>

        <div>
          <label htmlFor="headers" className="mb-1 block text-sm font-medium">
            Headers <span className="font-normal text-muted">(one per line, optional)</span>
          </label>
          <textarea
            id="headers"
            rows={3}
            spellCheck={false}
            placeholder={"Authorization: Bearer YOUR_TOKEN\nAccept: application/json"}
            value={headersText}
            onChange={(e) => setHeadersText(e.target.value)}
            className="field font-mono"
          />
          <p className="mt-1 text-xs text-muted">Sent once to the endpoint. Headers are never saved.</p>
        </div>

        {(method === "POST" || method === "PUT") && (
          <div>
            <label htmlFor="body" className="mb-1 block text-sm font-medium">
              Request body <span className="font-normal text-muted">(optional)</span>
            </label>
            <textarea
              id="body"
              rows={4}
              spellCheck={false}
              placeholder={'{"name": "Ada"}'}
              value={body}
              onChange={(e) => setBody(e.target.value)}
              className="field font-mono"
            />
          </div>
        )}

        {formError && (
          <p role="alert" className="rounded border border-sev-critical/30 bg-sevbg-critical px-3 py-2 text-sm text-sev-critical">
            {formError}
          </p>
        )}
        <button type="submit" disabled={running} className="btn-primary">
          {running ? "Sending…" : "Send request"}
        </button>
      </form>

      {result && (
        <section className="panel mt-6 px-5 py-5" aria-label="Result" aria-live="polite">
          <div className="flex flex-wrap items-baseline gap-x-6 gap-y-1">
            <p className={`text-3xl font-bold ${statusTone(result.status_code, result.error_type)}`}>
              {result.status_code ?? "No response"}
              {result.reason && <span className="ml-2 text-lg font-semibold">{result.reason}</span>}
            </p>
            <p className="text-sm text-muted">
              {result.response_time_ms != null && `${result.response_time_ms.toFixed(0)} ms`}
              {result.response_size_bytes != null && `, ${formatBytes(result.response_size_bytes)}`}
              {result.json_valid === true && ", valid JSON"}
              {result.json_valid === false && ", invalid JSON"}
            </p>
          </div>

          <ul className="mt-4 space-y-2">
            {result.observations.map((o, i) => (
              <li key={i} className="flex gap-3 text-sm">
                <span className={`mt-1.5 h-2.5 w-2.5 shrink-0 rounded-sm ${LEVEL_STYLE[o.level].dot}`} aria-hidden="true" />
                <span>
                  <span className="sr-only">{LEVEL_STYLE[o.level].label}: </span>
                  {o.message}
                </span>
              </li>
            ))}
          </ul>

          {result.body_preview && (
            <div className="mt-5">
              <p className="text-sm font-semibold">Response body</p>
              <pre className="code mt-1 max-h-80 overflow-auto px-3 py-2">
                <code>{result.body_preview}</code>
              </pre>
            </div>
          )}
        </section>
      )}

      <h2 className="mt-12 text-xl font-bold tracking-tight">Recent tests</h2>
      {history === null && <p className="mt-3 text-sm text-muted">Loading…</p>}
      {history?.length === 0 && (
        <p className="mt-3 text-sm text-muted">Your tests will appear here after you send a request.</p>
      )}
      {history && history.length > 0 && (
        <div className="panel mt-3 overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="border-b border-line text-muted">
              <tr>
                <th className="px-4 py-2 font-medium">Method</th>
                <th className="px-4 py-2 font-medium">URL</th>
                <th className="px-4 py-2 font-medium">Result</th>
                <th className="px-4 py-2 font-medium">Time</th>
                <th className="px-4 py-2 font-medium">When</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-line">
              {history.map((h) => (
                <tr key={h.id}>
                  <td className="px-4 py-2 font-mono">{h.method}</td>
                  <td className="max-w-xs truncate px-4 py-2 font-mono" title={h.url}>
                    {h.url}
                  </td>
                  <td className={`px-4 py-2 font-semibold ${statusTone(h.status_code, h.error_type)}`}>
                    {h.status_code ?? h.error_type?.replace("_", " ") ?? "failed"}
                  </td>
                  <td className="px-4 py-2">{h.response_time_ms != null ? `${h.response_time_ms.toFixed(0)} ms` : ""}</td>
                  <td className="whitespace-nowrap px-4 py-2 text-muted">{formatDate(h.created_at)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
