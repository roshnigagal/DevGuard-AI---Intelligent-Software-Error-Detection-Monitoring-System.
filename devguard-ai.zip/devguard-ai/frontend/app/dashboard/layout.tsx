import AuthGuard from "@/components/AuthGuard";
import Nav from "@/components/Nav";

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  return (
    <AuthGuard>
      <Nav />
      <main className="mx-auto max-w-5xl px-5 py-8">{children}</main>
    </AuthGuard>
  );
}
