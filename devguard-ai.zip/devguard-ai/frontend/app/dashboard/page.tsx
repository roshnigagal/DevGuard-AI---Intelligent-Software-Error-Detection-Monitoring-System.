"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { ChangeEvent, DragEvent, useCallback, useEffect, useRef, useState } from "react";
import SeverityStrip from "@/components/SeverityStrip";
import { apiFetch, errorMessage } from "@/lib/api";
import { formatDate } from "@/lib/format";
import type { ScanListItem } from "@/lib/types";

const MAX_BYTES = 10 * 1024 * 1024;

const STATUS_LABEL: Record<ScanListItem["status"], string> = {
  running: "Scanning",
  completed: "Completed",
  failed: "Failed",
};

export default function ScansPage() {
  const router = useRouter();
  const inputRef = useRef<HTMLInputElement>(null);
  const [scans, setScans] = useState<ScanListItem[] | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const [dragging, setDragging] = useState(false);

  const load = useCallback(async () => {
    try {
      setScans(await apiFetch<ScanListItem[]>("/api/scans"));
      setLoadError(null);
    } catch (err) {
      setLoadError(errorMessage(err, "Could not load your scans."));
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const anyRunning = scans?.some((s) => s.status === "running") ?? false;
  useEffect(() => {
    if (!anyRunning) return;
    const timer = setInterval(load, 3000);
    return () => clearInterval(timer);
  }, [anyRunning, load]);

  async function upload(file: File | undefined) {
    if (!file) return;
    setUploadError(null);
    if (!file.name.toLowerCase().endsWith(".zip")) {
      setUploadError("Choose a .zip file containing your project.");
      return;
    }
    if (file.size > MAX_BYTES) {
      setUploadError(
        `That file is ${(file.size / 1024 / 1024).toFixed(1)} MB and the limit is 10 MB. Remove node_modules, virtual environments and build folders, then zip it again.`
      );
      return;
    }
    setUploading(true);
    try {
      const form = new FormData();
      form.append("file", file);
      const created = await apiFetch<{ id: string }>("/api/scans", { method: "POST", body: form });
      router.push(`/dashboard/scans/${created.id}`);
    } catch (err) {
      setUploadError(errorMessage(err, "The upload failed."));
      setUploading(false);
    }
  }

  function onPick(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    e.target.value = ""; // allow choosing the same file again
    upload(file);
  }

  function onDrop(e: DragEvent<HTMLButtonElement>) {
    e.preventDefault();
    setDragging(false);
    upload(e.dataTransfer.files?.[0]);
  }

  async function remove(scan: ScanListItem) {
    if (!window.confirm(`Delete the report for ${scan.filename}?`)) return;
    try {
      await apiFetch<void>(`/api/scans/${scan.id}`, { method: "DELETE" });
      setScans((prev) => prev?.filter((s) => s.id !== scan.id) ?? null);
    } catch (err) {
      setLoadError(errorMessage(err, "Could not delete the scan."));
    }
  }

  return (
    <div>
      <h1 className="text-3xl font-bold tracking-tight">Code scans</h1>
      <p className="mt-2 max-w-xl text-muted">
        Upload a ZIP of a Python or JavaScript project. Your code is analysed, never executed.
      </p>

      <button
        type="button"
        disabled={uploading}
        onClick={() => inputRef.current?.click()}
        onDragOver={(e) => {
          e.preventDefault();
          setDragging(true);
        }}
        onDragLeave={() => setDragging(false)}
        onDrop={onDrop}
        className={`mt-6 block w-full rounded border-2 border-dashed px-6 py-10 text-left transition-colors disabled:opacity-60 ${
          dragging ? "border-brand bg-brand-soft" : "border-line bg-panel hover:border-brand/60"
        }`}
      >
        <span className="block text-lg font-semibold">
          {uploading ? "Uploading…" : "Drop your project ZIP here, or choose a file"}
        </span>
        <span className="mt-1 block text-sm text-muted">
          .zip, up to 10 MB. Leave out node_modules, virtual environments and build folders.
        </span>
      </button>
      <input
        ref={inputRef}
        type="file"
        accept=".zip,application/zip"
        onChange={onPick}
        className="hidden"
        aria-label="Choose a ZIP file"
      />
      {uploadError && (
        <p role="alert" className="mt-3 rounded border border-sev-critical/30 bg-sevbg-critical px-3 py-2 text-sm text-sev-critical">
          {uploadError}
        </p>
      )}

      <h2 className="mt-12 text-xl font-bold tracking-tight">Previous scans</h2>
      {loadError && (
        <p role="alert" className="mt-3 rounded border border-sev-critical/30 bg-sevbg-critical px-3 py-2 text-sm text-sev-critical">
          {loadError}
        </p>
      )}
      {scans === null && !loadError && <p className="mt-4 text-sm text-muted">Loading…</p>}
      {scans?.length === 0 && (
        <p className="mt-4 text-sm text-muted">
          No scans yet. Upload a ZIP of your project above to run your first scan.
        </p>
      )}
      {scans && scans.length > 0 && (
        <ul className="panel mt-4 divide-y divide-line">
          {scans.map((scan) => (
            <li key={scan.id} className="flex flex-wrap items-center gap-x-6 gap-y-2 px-4 py-3">
              <div className="min-w-0 flex-1 basis-56">
                <Link
                  href={`/dashboard/scans/${scan.id}`}
                  className="block truncate font-semibold text-brand-dark hover:underline"
                >
                  {scan.filename}
                </Link>
                <span className="text-xs text-muted">{formatDate(scan.created_at)}</span>
              </div>
              <div className="w-40">
                {scan.status === "completed" ? (
                  <>
                    <SeverityStrip counts={scan.summary?.by_severity} />
                    <span className="mt-1 block text-xs text-muted">
                      {scan.summary?.total ?? 0} finding{scan.summary?.total === 1 ? "" : "s"}
                      {scan.has_ai ? ", explained by Claude" : ""}
                    </span>
                  </>
                ) : (
                  <span className={`text-sm ${scan.status === "failed" ? "text-sev-critical" : "text-muted"}`}>
                    {STATUS_LABEL[scan.status]}
                  </span>
                )}
              </div>
              <button
                type="button"
                onClick={() => remove(scan)}
                className="text-sm text-muted underline hover:text-sev-critical"
                aria-label={`Delete ${scan.filename}`}
              >
                Delete
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
