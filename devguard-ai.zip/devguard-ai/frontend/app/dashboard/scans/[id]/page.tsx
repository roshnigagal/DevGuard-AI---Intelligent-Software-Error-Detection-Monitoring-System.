"use client";

import Link from "next/link";
import { useParams } from "next/navigation";
import { useCallback, useEffect, useMemo, useState } from "react";
import SeverityStrip, { GUTTER, SEVERITY_LABEL, SWATCH, SeverityBadge } from "@/components/SeverityStrip";
import { apiFetch, errorMessage } from "@/lib/api";
import { formatDate } from "@/lib/format";
import { AIAnalysis, AIIssue, Finding, SEVERITIES, ScanDetail, Severity } from "@/lib/types";

const PAGE_SIZE = 50;

function List({ title, items }: { title: string; items: string[] }) {
  if (!items.length) return null;
  return (
    <div className="mt-3">
      <p className="text-sm font-semibold">{title}</p>
      <ul className="mt-1 list-disc space-y-0.5 pl-5 text-sm">
        {items.map((item, i) => (
          <li key={i}>{item}</li>
        ))}
      </ul>
    </div>
  );
}

function FindingRow({ finding, issue }: { finding: Finding; issue?: AIIssue }) {
  return (
    <li className={`border-b border-l-4 border-line bg-panel px-4 py-3 ${GUTTER[finding.severity]}`}>
      <div className="flex flex-wrap items-baseline gap-x-3 gap-y-1">
        <span className="break-all font-mono text-[13px]">
          {finding.file}
          <span className="text-muted">:{finding.line ?? "?"}</span>
        </span>
        <SeverityBadge severity={finding.severity} />
        <span className="font-mono text-xs text-muted">{finding.rule_id}</span>
        <span className="text-xs text-muted">{finding.tool}</span>
        {finding.category === "security" && (
          <span className="rounded-sm bg-brand-soft px-1.5 py-0.5 text-xs font-semibold text-brand-dark">Security</span>
        )}
      </div>
      <p className="mt-2 text-sm">{finding.message}</p>
      {finding.code_line && (
        <div className="code mt-2 flex">
          <span className="w-12 shrink-0 select-none border-r border-line py-1.5 pr-3 text-right text-muted">
            {finding.line}
          </span>
          <code className="whitespace-pre px-3 py-1.5">{finding.code_line}</code>
        </div>
      )}
      {finding.more_info && (
        <a
          href={finding.more_info}
          target="_blank"
          rel="noopener noreferrer"
          className="mt-2 inline-block text-xs text-brand underline"
        >
          Rule documentation
        </a>
      )}

      {issue && (
        <div className="mt-3 rounded border border-brand/20 bg-brand-soft/50 px-4 py-3">
          <p className="text-sm font-semibold text-brand-dark">
            Claude <span className="font-normal text-muted">({issue.confidence} confidence)</span>
          </p>
          <p className="mt-1 text-sm">{issue.problem}</p>
          <List title="Likely causes" items={issue.possible_causes} />
          <List title="How to fix it" items={issue.recommended_solution} />
          {issue.suggested_fix && (
            <div className="mt-3">
              <p className="text-sm font-semibold">Suggested fix</p>
              <pre className="code mt-1 bg-panel px-3 py-2">
                <code>{issue.suggested_fix}</code>
              </pre>
            </div>
          )}
        </div>
      )}
    </li>
  );
}

function AIPanel({ analysis }: { analysis: AIAnalysis }) {
  return (
    <div className="mt-4 rounded border border-brand/20 bg-brand-soft/50 px-4 py-4">
      <p className="text-sm">{analysis.summary}</p>
      <List title="Fix these first" items={analysis.priority_actions} />
      <p className="mt-3 text-xs text-muted">
        Claude reviewed the {analysis.analyzed_count} most severe findings. Check suggested fixes before
        using them: AI can be wrong.
      </p>
    </div>
  );
}

export default function ScanReportPage() {
  const params = useParams<{ id: string }>();
  const id = params.id;
  const [scan, setScan] = useState<ScanDetail | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [aiError, setAiError] = useState<string | null>(null);
  const [filter, setFilter] = useState<Severity | "all">("all");
  const [showAll, setShowAll] = useState(false);

  const load = useCallback(async () => {
    try {
      setScan(await apiFetch<ScanDetail>(`/api/scans/${id}`));
      setError(null);
    } catch (err) {
      setError(errorMessage(err, "Could not load this scan."));
    }
  }, [id]);

  useEffect(() => {
    load();
  }, [load]);

  const running = scan?.status === "running";
  useEffect(() => {
    if (!running) return;
    const timer = setInterval(load, 2000);
    return () => clearInterval(timer);
  }, [running, load]);

  async function analyze() {
    setAnalyzing(true);
    setAiError(null);
    try {
      const analysis = await apiFetch<AIAnalysis>(`/api/scans/${id}/analyze`, { method: "POST" });
      setScan((prev) => (prev ? { ...prev, ai_analysis: analysis, has_ai: true } : prev));
    } catch (err) {
      setAiError(errorMessage(err, "The AI analysis failed."));
    } finally {
      setAnalyzing(false);
    }
  }

  const issuesById = useMemo(() => {
    const map = new Map<number, AIIssue>();
    scan?.ai_analysis?.issues.forEach((issue) => map.set(issue.finding_id, issue));
    return map;
  }, [scan?.ai_analysis]);

  const findings = scan?.findings ?? [];
  const filtered = filter === "all" ? findings : findings.filter((f) => f.severity === filter);
  const visible = showAll ? filtered : filtered.slice(0, PAGE_SIZE);

  if (error && !scan) {
    return (
      <div>
        <Link href="/dashboard" className="text-sm text-brand underline">
          Back to all scans
        </Link>
        <p role="alert" className="mt-4 rounded border border-sev-critical/30 bg-sevbg-critical px-3 py-2 text-sm text-sev-critical">
          {error}
        </p>
      </div>
    );
  }
  if (!scan) return <p className="text-sm text-muted">Loading…</p>;

  const summary = scan.summary;
  const hasFindings = (summary?.total ?? 0) > 0;

  return (
    <div>
      <Link href="/dashboard" className="text-sm text-brand underline">
        Back to all scans
      </Link>
      <h1 className="mt-3 break-all text-3xl font-bold tracking-tight">{scan.filename}</h1>
      <p className="mt-1 text-sm text-muted">Uploaded {formatDate(scan.created_at)}</p>

      {running && (
        <p role="status" className="mt-6 rounded border border-line bg-panel px-4 py-4 text-sm">
          Scanning your project. This usually takes a few seconds and the page will update by itself.
        </p>
      )}
      {scan.status === "failed" && (
        <p role="alert" className="mt-6 rounded border border-sev-critical/30 bg-sevbg-critical px-4 py-4 text-sm text-sev-critical">
          {scan.error ?? "The scan failed."}
        </p>
      )}

      {scan.status === "completed" && summary && (
        <>
          <section className="panel mt-6 px-5 py-5" aria-label="Summary">
            <div className="flex flex-wrap items-baseline gap-x-4">
              <p className="text-3xl font-bold">
                {summary.total_found} <span className="text-lg font-semibold">finding{summary.total_found === 1 ? "" : "s"}</span>
              </p>
              <p className="text-sm text-muted">
                in {summary.files_scanned} Python and JavaScript file{summary.files_scanned === 1 ? "" : "s"}
              </p>
            </div>
            <SeverityStrip counts={summary.by_severity} className="mt-4 !h-3" />
            <ul className="mt-3 flex flex-wrap gap-x-5 gap-y-1 text-sm">
              {SEVERITIES.map((s) => (
                <li key={s} className="flex items-center gap-1.5">
                  <span className={`inline-block h-2.5 w-2.5 rounded-sm ${SWATCH[s]}`} aria-hidden="true" />
                  {summary.by_severity[s]} {SEVERITY_LABEL[s].toLowerCase()}
                </li>
              ))}
            </ul>

            {scan.tools && scan.tools.length > 0 && (
              <ul className="mt-5 space-y-1 border-t border-line pt-4 text-sm text-muted">
                {scan.tools.map((t) => (
                  <li key={t.name}>
                    <span className="font-semibold text-ink">{t.name}</span>{" "}
                    {t.status === "ok" ? `ran and found ${t.findings}` : `did not run: ${t.detail}`}
                  </li>
                ))}
              </ul>
            )}
            {summary.notes
              .filter((n) => !scan.tools?.some((t) => n.startsWith(`${t.name}:`)))
              .map((n, i) => (
                <p key={i} className="mt-2 text-sm text-muted">
                  {n}
                </p>
              ))}
          </section>

          {hasFindings && (
            <section className="mt-8" aria-label="AI analysis">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <h2 className="text-xl font-bold tracking-tight">Explain with Claude</h2>
                <button type="button" onClick={analyze} disabled={analyzing} className="btn-primary">
                  {analyzing ? "Claude is reading your findings…" : scan.ai_analysis ? "Analyse again" : "Explain these findings"}
                </button>
              </div>
              {!scan.ai_analysis && !analyzing && (
                <p className="mt-2 max-w-xl text-sm text-muted">
                  Claude explains the most severe findings in plain language, lists likely causes and suggests fixes.
                </p>
              )}
              {aiError && (
                <p role="alert" className="mt-3 rounded border border-sev-critical/30 bg-sevbg-critical px-3 py-2 text-sm text-sev-critical">
                  {aiError}
                </p>
              )}
              {scan.ai_analysis && <AIPanel analysis={scan.ai_analysis} />}
            </section>
          )}

          <section className="mt-10" aria-label="Findings">
            <h2 className="text-xl font-bold tracking-tight">Findings</h2>
            {!hasFindings ? (
              <p className="mt-3 rounded border border-ok/30 bg-[#E4F2EA] px-4 py-4 text-sm text-ok">
                Nothing was flagged. That is a good sign, but static analysis cannot catch every bug.
              </p>
            ) : (
              <>
                <div className="mt-3 flex flex-wrap gap-2" role="group" aria-label="Filter by severity">
                  {(["all", ...SEVERITIES] as const).map((s) => {
                    const count = s === "all" ? findings.length : findings.filter((f) => f.severity === s).length;
                    if (s !== "all" && count === 0) return null;
                    const active = filter === s;
                    return (
                      <button
                        key={s}
                        type="button"
                        aria-pressed={active}
                        onClick={() => {
                          setFilter(s);
                          setShowAll(false);
                        }}
                        className={`rounded border px-3 py-1 text-sm ${
                          active ? "border-brand bg-brand text-white" : "border-line bg-panel hover:border-ink/40"
                        }`}
                      >
                        {s === "all" ? "All" : SEVERITY_LABEL[s]} ({count})
                      </button>
                    );
                  })}
                </div>
                {summary.truncated && (
                  <p className="mt-3 text-sm text-muted">
                    Showing the {findings.length} most severe of {summary.total_found} findings.
                  </p>
                )}
                <ul className="mt-4 border-t border-line">
                  {visible.map((f) => (
                    <FindingRow key={f.id} finding={f} issue={issuesById.get(f.id)} />
                  ))}
                </ul>
                {!showAll && filtered.length > PAGE_SIZE && (
                  <button type="button" onClick={() => setShowAll(true)} className="btn-quiet mt-4">
                    Show all {filtered.length}
                  </button>
                )}
              </>
            )}
          </section>
        </>
      )}
    </div>
  );
}
