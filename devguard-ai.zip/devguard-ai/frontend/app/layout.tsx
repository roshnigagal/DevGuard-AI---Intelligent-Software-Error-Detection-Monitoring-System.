import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "DevGuard AI",
  description:
    "Upload a project, test an API endpoint, and get every problem explained in plain language with a suggested fix.",
};

// Fonts load from Google Fonts. If they cannot load (offline), the system fonts defined in
// globals.css are used instead, so the app still works.
const FONT_URL =
  "https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:wght@400..800&family=JetBrains+Mono:wght@400;500&display=swap";

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link rel="stylesheet" href={FONT_URL} />
      </head>
      <body>{children}</body>
    </html>
  );
}
