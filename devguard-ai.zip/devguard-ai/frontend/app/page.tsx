import Link from "next/link";

const SAMPLE_CODE = 'query = "SELECT * FROM users WHERE id = " + user_id';
const SAMPLE_FIX = 'cursor.execute("SELECT * FROM users WHERE id = %s", (user_id,))';

const FEATURES = [
  {
    title: "Code scan",
    body: "Upload a ZIP of a Python or JavaScript project. Ruff, Bandit and ESLint check it for bugs, security problems and code quality issues. Your code is read, never run.",
  },
  {
    title: "API tester",
    body: "Send a GET, POST, PUT or DELETE request to an endpoint. See the status, response time, whether the JSON is valid, and what a 401 or timeout most likely means.",
  },
  {
    title: "AI explanations",
    body: "Claude reads the findings and explains each one in plain language: why it happens, how to fix it, and a corrected snippet when one applies.",
  },
  {
    title: "Saved history",
    body: "Every scan is stored in your account so you can compare reports as you fix things.",
  },
];

export default function Landing() {
  return (
    <div className="min-h-screen">
      <header className="mx-auto flex max-w-5xl items-center justify-between px-5 py-5">
        <span className="text-lg font-bold tracking-tight">
          DevGuard <span className="font-normal text-muted">AI</span>
        </span>
        <nav className="flex items-center gap-2" aria-label="Account">
          <Link href="/login" className="btn-quiet">
            Sign in
          </Link>
          <Link href="/register" className="btn-primary">
            Create account
          </Link>
        </nav>
      </header>

      <main>
        <section className="mx-auto grid max-w-5xl items-center gap-10 px-5 pb-16 pt-10 lg:grid-cols-[1fr_1.1fr] lg:pt-16">
          <div>
            <h1 className="max-w-md text-4xl font-bold leading-[1.1] tracking-tight sm:text-5xl">
              Upload your project. Get every problem explained.
            </h1>
            <p className="mt-5 max-w-md text-lg leading-relaxed text-muted">
              DevGuard AI scans your code, tests your API endpoints, and has Claude explain each
              finding with a suggested fix.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link href="/register" className="btn-primary px-5 py-2.5">
                Scan a project
              </Link>
              <Link href="/login" className="btn-quiet px-5 py-2.5">
                Sign in
              </Link>
            </div>
          </div>

          {/* A real-looking finding: the thing the product produces */}
          <div className="panel overflow-hidden" aria-label="Example finding with an AI explanation">
            <div className="border-l-4 border-l-sev-medium px-4 py-3">
              <div className="flex flex-wrap items-baseline gap-x-3 gap-y-1">
                <span className="break-all font-mono text-[13px]">
                  backend/db.py<span className="text-muted">:25</span>
                </span>
                <span className="rounded-sm bg-sevbg-medium px-1.5 py-0.5 text-xs font-semibold text-sev-medium">
                  Medium
                </span>
                <span className="font-mono text-xs text-muted">B608</span>
              </div>
              <p className="mt-2 text-sm">Possible SQL injection via string-based query construction.</p>
              <div className="code mt-3 flex">
                <span className="w-10 shrink-0 select-none border-r border-line py-2 pr-3 text-right text-muted">25</span>
                <code className="whitespace-pre px-3 py-2">{SAMPLE_CODE}</code>
              </div>
            </div>
            <div className="border-t border-line bg-brand-soft/60 px-4 py-4 text-sm leading-relaxed">
              <p className="font-semibold text-brand-dark">Claude</p>
              <p className="mt-1">
                The user id is pasted straight into the SQL text, so anyone who controls that value can
                change what the query does. Pass it as a parameter and the database will treat it as
                data only.
              </p>
              <div className="code mt-3 bg-panel">
                <code className="block whitespace-pre px-3 py-2">{SAMPLE_FIX}</code>
              </div>
            </div>
          </div>
        </section>

        <section className="border-t border-line bg-panel">
          <div className="mx-auto max-w-5xl px-5 py-14">
            <h2 className="text-2xl font-bold tracking-tight">What it checks</h2>
            <dl className="mt-8 grid gap-x-12 gap-y-8 sm:grid-cols-2">
              {FEATURES.map((f) => (
                <div key={f.title}>
                  <dt className="font-semibold">{f.title}</dt>
                  <dd className="mt-1 max-w-md text-sm leading-relaxed text-muted">{f.body}</dd>
                </div>
              ))}
            </dl>
            <p className="mt-10 max-w-xl text-sm text-muted">
              Static analysis catches many bugs and security problems, but not all of them. Treat a clean
              report as a good sign, not a guarantee.
            </p>
          </div>
        </section>
      </main>
    </div>
  );
}
