import AuthForm from "@/components/AuthForm";

export const metadata = { title: "Create account - DevGuard AI" };

export default function RegisterPage() {
  return <AuthForm mode="register" />;
}
