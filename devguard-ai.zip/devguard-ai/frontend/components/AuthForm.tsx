"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { FormEvent, useState } from "react";
import { getSupabase } from "@/lib/supabase";

function friendlyAuthError(err: unknown): string {
  const message = err instanceof Error ? err.message : "";
  if (/email not confirmed/i.test(message)) return "Verify your email first. Open the link we sent you, then sign in.";
  if (/invalid login credentials/i.test(message)) return "The email or password is incorrect.";
  if (/already registered/i.test(message)) return "An account with this email already exists. Sign in instead.";
  if (/rate limit|too many/i.test(message)) return "Too many attempts. Wait a few minutes and try again.";
  return message || "Something went wrong. Try again.";
}

export default function AuthForm({ mode }: { mode: "login" | "register" }) {
  const router = useRouter();
  const isRegister = mode === "register";
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError(null);
    setNotice(null);
    if (password.length < 8) {
      setError("Use a password with at least 8 characters.");
      return;
    }
    setBusy(true);
    try {
      const supabase = getSupabase();
      if (isRegister) {
        const { data, error: signUpError } = await supabase.auth.signUp({
          email,
          password,
          options: { emailRedirectTo: `${window.location.origin}/dashboard` },
        });
        if (signUpError) throw signUpError;
        if (data.session) {
          router.replace("/dashboard"); // e-mail confirmation is switched off in Supabase
          return;
        }
        setNotice(`We sent a verification link to ${email}. Open it to activate your account.`);
      } else {
        const { error: signInError } = await supabase.auth.signInWithPassword({ email, password });
        if (signInError) throw signInError;
        router.replace("/dashboard");
      }
    } catch (err) {
      setError(friendlyAuthError(err));
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="mx-auto flex min-h-screen max-w-sm flex-col justify-center px-5 py-12">
      <Link href="/" className="mb-10 text-lg font-bold tracking-tight">
        DevGuard <span className="font-normal text-muted">AI</span>
      </Link>
      <h1 className="text-3xl font-bold tracking-tight">
        {isRegister ? "Create your account" : "Sign in"}
      </h1>
      <p className="mt-2 text-sm text-muted">
        {isRegister
          ? "You will get an email to verify your address before you can scan."
          : "Welcome back. Your scan history is waiting."}
      </p>

      <form onSubmit={onSubmit} className="mt-8 space-y-4" noValidate={false}>
        <div>
          <label htmlFor="email" className="mb-1 block text-sm font-medium">
            Email
          </label>
          <input
            id="email"
            type="email"
            required
            autoComplete="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="field"
          />
        </div>
        <div>
          <label htmlFor="password" className="mb-1 block text-sm font-medium">
            Password
          </label>
          <input
            id="password"
            type="password"
            required
            minLength={8}
            autoComplete={isRegister ? "new-password" : "current-password"}
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="field"
          />
          {isRegister && <p className="mt-1 text-xs text-muted">At least 8 characters.</p>}
        </div>

        {error && (
          <p role="alert" className="rounded border border-sev-critical/30 bg-sevbg-critical px-3 py-2 text-sm text-sev-critical">
            {error}
          </p>
        )}
        {notice && (
          <p role="status" className="rounded border border-ok/30 bg-[#E4F2EA] px-3 py-2 text-sm text-ok">
            {notice}
          </p>
        )}

        <button type="submit" disabled={busy} className="btn-primary w-full">
          {busy ? "Please wait…" : isRegister ? "Create account" : "Sign in"}
        </button>
      </form>

      <p className="mt-6 text-sm text-muted">
        {isRegister ? "Already have an account? " : "New to DevGuard AI? "}
        <Link href={isRegister ? "/login" : "/register"} className="font-semibold text-brand underline">
          {isRegister ? "Sign in" : "Create an account"}
        </Link>
      </p>
    </main>
  );
}
