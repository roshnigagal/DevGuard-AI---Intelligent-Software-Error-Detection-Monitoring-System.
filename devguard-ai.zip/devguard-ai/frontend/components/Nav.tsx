"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { getSupabase } from "@/lib/supabase";

const LINKS = [
  { href: "/dashboard", label: "Code scans" },
  { href: "/dashboard/api-tester", label: "API tester" },
];

export default function Nav() {
  const pathname = usePathname();
  const router = useRouter();
  const [email, setEmail] = useState<string | null>(null);

  useEffect(() => {
    getSupabase()
      .auth.getUser()
      .then(({ data }) => setEmail(data.user?.email ?? null));
  }, []);

  async function signOut() {
    await getSupabase().auth.signOut();
    router.replace("/login");
  }

  return (
    <header className="border-b border-line bg-panel">
      <div className="mx-auto flex max-w-5xl flex-wrap items-center gap-x-8 gap-y-2 px-5 py-3">
        <Link href="/dashboard" className="text-lg font-bold tracking-tight">
          DevGuard <span className="font-normal text-muted">AI</span>
        </Link>
        <nav className="flex gap-1" aria-label="Main">
          {LINKS.map((l) => {
            const active =
              l.href === "/dashboard" ? pathname === l.href || pathname.startsWith("/dashboard/scans") : pathname.startsWith(l.href);
            return (
              <Link
                key={l.href}
                href={l.href}
                aria-current={active ? "page" : undefined}
                className={`rounded px-3 py-1.5 text-sm font-medium ${
                  active ? "bg-brand-soft text-brand-dark" : "text-muted hover:text-ink"
                }`}
              >
                {l.label}
              </Link>
            );
          })}
        </nav>
        <div className="ml-auto flex items-center gap-3 text-sm">
          {email && <span className="hidden max-w-[16rem] truncate text-muted sm:inline">{email}</span>}
          <button type="button" onClick={signOut} className="btn-quiet !px-3 !py-1.5">
            Sign out
          </button>
        </div>
      </div>
    </header>
  );
}
