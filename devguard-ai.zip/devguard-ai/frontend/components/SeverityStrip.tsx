import { SEVERITIES, Severity } from "@/lib/types";

// Full class names are written out so Tailwind can see them.
const FILL: Record<Severity, string> = {
  critical: "bg-sev-critical",
  high: "bg-sev-high",
  medium: "bg-sev-medium",
  low: "bg-sev-low",
  info: "bg-sev-info",
};
const BADGE: Record<Severity, string> = {
  critical: "bg-sevbg-critical text-sev-critical",
  high: "bg-sevbg-high text-sev-high",
  medium: "bg-sevbg-medium text-sev-medium",
  low: "bg-sevbg-low text-sev-low",
  info: "bg-sevbg-info text-sev-info",
};
export const GUTTER: Record<Severity, string> = {
  critical: "border-l-sev-critical",
  high: "border-l-sev-high",
  medium: "border-l-sev-medium",
  low: "border-l-sev-low",
  info: "border-l-sev-info",
};
export const SEVERITY_LABEL: Record<Severity, string> = {
  critical: "Critical",
  high: "High",
  medium: "Medium",
  low: "Low",
  info: "Info",
};
export const SWATCH = FILL;

export function SeverityBadge({ severity }: { severity: Severity }) {
  return (
    <span className={`rounded-sm px-1.5 py-0.5 text-xs font-semibold ${BADGE[severity]}`}>
      {SEVERITY_LABEL[severity]}
    </span>
  );
}

/** A single bar showing how a scan's findings split across severities. */
export default function SeverityStrip({
  counts,
  className = "",
}: {
  counts: Record<Severity, number> | null | undefined;
  className?: string;
}) {
  const total = counts ? SEVERITIES.reduce((n, s) => n + (counts[s] ?? 0), 0) : 0;

  if (!counts || total === 0) {
    return (
      <div
        role="img"
        aria-label={counts ? "No findings" : "Not scanned yet"}
        className={`h-2 rounded-sm ${counts ? "bg-ok" : "bg-line"} ${className}`}
      />
    );
  }
  const label = SEVERITIES.filter((s) => counts[s] > 0)
    .map((s) => `${counts[s]} ${s}`)
    .join(", ");
  return (
    <div
      role="img"
      aria-label={label}
      className={`flex h-2 gap-px overflow-hidden rounded-sm bg-line ${className}`}
    >
      {SEVERITIES.map((s) =>
        counts[s] > 0 ? (
          <div key={s} className={FILL[s]} style={{ width: `${(counts[s] / total) * 100}%` }} />
        ) : null
      )}
    </div>
  );
}
