export type Severity = "critical" | "high" | "medium" | "low" | "info";
export const SEVERITIES: Severity[] = ["critical", "high", "medium", "low", "info"];

export interface Finding {
  id: number;
  tool: string;
  rule_id: string;
  severity: Severity;
  category: "bug" | "security" | "quality";
  file: string;
  line: number | null;
  column: number | null;
  message: string;
  more_info: string | null;
  code_line: string | null;
}

export interface ScanSummary {
  total: number;
  total_found: number;
  truncated: boolean;
  files_scanned: number;
  by_severity: Record<Severity, number>;
  by_tool: Record<string, number>;
  by_category: Record<string, number>;
  notes: string[];
}

export interface ToolStatus {
  name: string;
  status: "ok" | "skipped" | "error" | "timeout";
  findings: number;
  detail: string;
}

export interface AIIssue {
  finding_id: number;
  problem: string;
  possible_causes: string[];
  recommended_solution: string[];
  suggested_fix: string | null;
  confidence: "high" | "medium" | "low";
}

export interface AIAnalysis {
  model: string;
  generated_at: string;
  analyzed_count: number;
  summary: string;
  priority_actions: string[];
  issues: AIIssue[];
}

export interface ScanListItem {
  id: string;
  filename: string;
  status: "running" | "completed" | "failed";
  summary: ScanSummary | null;
  languages: Record<string, number> | null;
  error: string | null;
  created_at: string;
  finished_at: string | null;
  has_ai: boolean;
}

export interface ScanDetail extends ScanListItem {
  tools: ToolStatus[] | null;
  findings: Finding[] | null;
  ai_analysis: AIAnalysis | null;
}

export interface Observation {
  level: "ok" | "info" | "warning" | "error";
  message: string;
}

export interface ApiTestResult {
  url: string;
  method: string;
  ok: boolean;
  status_code: number | null;
  reason: string | null;
  response_time_ms: number | null;
  response_size_bytes: number | null;
  truncated: boolean;
  content_type: string | null;
  json_valid: boolean | null;
  body_preview: string | null;
  redirects: string[];
  error_type: string | null;
  error_message: string | null;
  observations: Observation[];
}

export interface ApiTestHistoryItem {
  id: string;
  url: string;
  method: string;
  ok: boolean;
  status_code: number | null;
  response_time_ms: number | null;
  error_type: string | null;
  created_at: string;
}
