import type { Config } from "tailwindcss";

// Palette: cool paper and ink-blue text; one ultramarine accent for actions;
// severity colours are the only other hues so they always mean something.
const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        paper: "#F2F5F7",
        panel: "#FFFFFF",
        ink: "#13202B",
        muted: "#5B6B79",
        line: "#D3DCE3",
        ok: "#1F6B4A",
        brand: { DEFAULT: "#2A3FD0", dark: "#1F2FA6", soft: "#E6E9FB" },
        sev: {
          critical: "#A31621",
          high: "#B03A0A",
          medium: "#8A6200",
          low: "#2F6275",
          info: "#55616C",
        },
        sevbg: {
          critical: "#FBE7E9",
          high: "#FCE9DE",
          medium: "#F8EFD3",
          low: "#E2EEF2",
          info: "#EAEEF1",
        },
      },
      fontFamily: {
        sans: ["var(--font-sans)", "system-ui", "sans-serif"],
        mono: ["var(--font-mono)", "ui-monospace", "SFMono-Regular", "monospace"],
      },
    },
  },
  plugins: [],
};
export default config;
