@echo off
rem ======================================================================
rem  DevGuard AI - one-file setup and launcher for Windows.
rem
rem    start.bat          set everything up, first time only, and start the app
rem    start.bat setup    install and configure only
rem    start.bat run      start only, after setup
rem    start.bat config   re-enter your Supabase and Anthropic keys
rem    start.bat test     run the backend tests
rem
rem  Double-click it, or run it from Command Prompt or PowerShell as  .\start.bat
rem  Extract the ZIP first. Do not run this from inside the ZIP.
rem ======================================================================
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"

set "SELF=%~f0"
set "ROOT=%~dp0"
set "BACKEND=%ROOT%backend"
set "FRONTEND=%ROOT%frontend"
set "LOGS=%ROOT%logs"
set "VENVPY=%BACKEND%\venv\Scripts\python.exe"
set "CHECK=%BACKEND%\tools\check.py"
if not defined BACKEND_PORT set "BACKEND_PORT=8000"
if not defined FRONTEND_PORT set "FRONTEND_PORT=3000"
if not exist "%LOGS%" mkdir "%LOGS%"

set "ACTION=%~1"
if "%ACTION%"=="" set "ACTION=start"
if /i "%ACTION%"=="start"     goto :cmd_start
if /i "%ACTION%"=="setup"     goto :cmd_setup
if /i "%ACTION%"=="run"       goto :cmd_run
if /i "%ACTION%"=="config"    goto :cmd_config
if /i "%ACTION%"=="test"      goto :cmd_test
if /i "%ACTION%"=="_backend"  goto :child_backend
if /i "%ACTION%"=="_frontend" goto :child_frontend
goto :usage

rem ----------------------------------------------------------------------
:usage
echo Usage: start.bat [start ^| setup ^| run ^| config ^| test]
exit /b 1

rem ----------------------------------------------------------------------
:cmd_start
call :setup_all || exit /b 1
call :do_run
exit /b %errorlevel%

:cmd_setup
set "FORCE=1"
call :setup_all || exit /b 1
echo.
echo Setup finished. Start the app with:  start.bat run
pause
exit /b 0

:cmd_run
call :do_run
exit /b %errorlevel%

:cmd_config
call :configure 1
pause
exit /b 0

:cmd_test
if not exist "%VENVPY%" (
  call :die "Not set up yet." "Run:  start.bat setup"
  exit /b 1
)
pushd "%BACKEND%"
"%VENVPY%" -m unittest discover -s tests -t .
popd
pause
exit /b 0

rem ----------------------------------------------------------------------
rem  Shared helpers
rem ----------------------------------------------------------------------
:die
echo.
echo ERROR: %~1
if not "%~2"=="" echo        %~2
if not "%~3"=="" echo        %~3
if not "%~4"=="" echo        %~4
echo.
pause
exit /b 1

:find_python
set "PY="
call :try_python "py -3"
if not defined PY call :try_python "python"
if not defined PY call :try_python "python3"
exit /b 0

:try_python
%~1 -c "import sys; sys.exit(0 if (sys.version_info[0] == 3 and sys.version_info[1] >= 10) else 1)" >nul 2>&1
if not errorlevel 1 set "PY=%~1"
exit /b 0

:need_node
where node >nul 2>&1
if errorlevel 1 (
  call :die "Node.js was not found." "Install the LTS version from https://nodejs.org" "Then close this window, open a new one, and run start.bat again."
  exit /b 1
)
node -e "process.exit(parseInt(process.versions.node) >= 18 ? 0 : 1)" >nul 2>&1
if errorlevel 1 (
  call :die "Your Node.js version is too old. Version 18 or newer is needed." "Install the LTS version from https://nodejs.org" "Then close this window, open a new one, and run start.bat again."
  exit /b 1
)
where npm >nul 2>&1
if errorlevel 1 (
  call :die "npm was not found." "Reinstall Node.js from https://nodejs.org - npm comes with it."
  exit /b 1
)
exit /b 0

rem Removes quotes and surrounding spaces from the variable whose name is in %1
:clean
if not defined %~1 exit /b 0
set "%~1=!%~1:"=!"
for /f "tokens=* delims= " %%A in ("!%~1!") do set "%~1=%%A"
:clean_tail
if not defined %~1 exit /b 0
if "!%~1:~-1!"==" " set "%~1=!%~1:~0,-1!" & goto :clean_tail
exit /b 0

rem ----------------------------------------------------------------------
rem  Setup
rem ----------------------------------------------------------------------
:setup_all
call :setup_backend || exit /b 1
call :setup_eslint
call :setup_frontend || exit /b 1
call :configure 0
exit /b 0

:setup_backend
echo.
echo === Backend: Python environment ===
call :find_python
if not defined PY (
  call :die "Python 3.10 or newer was not found." "Install it from https://www.python.org/downloads/ and TICK the box Add python.exe to PATH." "Then close this window, open a new one, and run start.bat again."
  exit /b 1
)
echo Using %PY%
%PY% --version

if not exist "%VENVPY%" (
  echo Creating the virtual environment...
  %PY% -m venv "%BACKEND%\venv"
)
if not exist "%VENVPY%" (
  call :die "Could not create the Python virtual environment." "Delete the folder backend\venv if it exists, then run start.bat again."
  exit /b 1
)

set "NEED_PIP=1"
if exist "%BACKEND%\venv\.deps_ok" if not "%FORCE%"=="1" set "NEED_PIP=0"
if "%NEED_PIP%"=="1" (
  echo Installing Python packages - this can take a minute...
  "%VENVPY%" -m pip install -r "%BACKEND%\requirements.txt" --log "%LOGS%\pip.log"
  if errorlevel 1 (
    call :die "pip could not install the Python packages." "Read the error above. Most often it is a network problem - check your internet and run start.bat again." "A detailed log is saved in logs\pip.log"
    exit /b 1
  )
  echo ok> "%BACKEND%\venv\.deps_ok"
  echo Python packages installed.
) else (
  echo Python packages already installed.
)
exit /b 0

:setup_eslint
echo.
echo === Backend: ESLint, which enables JavaScript scanning ===
if exist "%BACKEND%\tools\eslint\node_modules\eslint" (
  echo ESLint already installed.
  exit /b 0
)
where npm >nul 2>&1
if errorlevel 1 (
  echo npm was not found. JavaScript scanning will be skipped. Python scanning still works.
  exit /b 0
)
pushd "%BACKEND%\tools\eslint"
call npm install --no-audit --no-fund --loglevel=error
set "RC=!errorlevel!"
popd
if "!RC!"=="0" (
  echo ESLint installed.
) else (
  echo ESLint did not install. The app still works, but JavaScript files will not be scanned.
)
exit /b 0

:setup_frontend
echo.
echo === Frontend: Node packages ===
call :need_node || exit /b 1
for /f "delims=" %%V in ('node --version') do echo Node %%V

set "NEED_NPM=1"
if exist "%FRONTEND%\node_modules\next\dist\bin\next" if exist "%FRONTEND%\node_modules\.deps_ok" if not "%FORCE%"=="1" set "NEED_NPM=0"
if "%NEED_NPM%"=="1" (
  echo Installing Node packages - the first time takes a few minutes...
  pushd "%FRONTEND%"
  call npm install --no-audit --no-fund
  set "RC=!errorlevel!"
  popd
  if not "!RC!"=="0" (
    call :die "npm install failed." "Read the error above. Check your internet connection and run start.bat again."
    exit /b 1
  )
  echo ok> "%FRONTEND%\node_modules\.deps_ok"
  echo Node packages installed.
) else (
  echo Node packages already installed.
)
exit /b 0

rem ----------------------------------------------------------------------
rem  Configuration - %1 is 1 to force re-entering the keys
rem ----------------------------------------------------------------------
:configure
if not "%~1"=="1" if exist "%BACKEND%\.env" if exist "%FRONTEND%\.env.local" (
  echo.
  echo Configuration files already exist. Run  start.bat config  to change them.
  exit /b 0
)

echo.
echo === Configuration ===
echo You need three values. Press Enter to skip any of them and add them later.
echo.
echo   Supabase, free: https://supabase.com  then  your project  then  Project Settings  then  API
echo     1. Project URL            looks like  https://abcdxyz.supabase.co
echo     2. anon or publishable key   a long text starting with eyJ or sb_publishable_
echo   Anthropic, optional: https://console.anthropic.com  then  API keys
echo     3. API key                starts with sk-ant-   and is only needed for Explain with Claude
echo.
echo   Tip: right-click in this window to paste. The text will be visible while you paste.
echo.

:ask_url
set "IN_URL="
set /p "IN_URL=1. Supabase Project URL: "
call :clean IN_URL
if not defined IN_URL goto :ask_url_done
if /i "!IN_URL:~0,4!"=="http" goto :ask_url_done
echo That does not look like a URL. It should start with https://  - or press Enter to skip.
goto :ask_url
:ask_url_done
if defined IN_URL if "!IN_URL:~-1!"=="/" set "IN_URL=!IN_URL:~0,-1!"

:ask_key
set "IN_KEY="
set /p "IN_KEY=2. Supabase anon or publishable key: "
call :clean IN_KEY
if not defined IN_KEY goto :ask_key_done
if not "!IN_KEY:~19,1!"=="" goto :ask_key_done
echo That looks too short to be a key. Paste the whole key - or press Enter to skip.
goto :ask_key
:ask_key_done

set "IN_AI="
set /p "IN_AI=3. Anthropic API key, optional: "
call :clean IN_AI

if exist "%BACKEND%\.env" copy /y "%BACKEND%\.env" "%BACKEND%\.env.bak" >nul
if exist "%FRONTEND%\.env.local" copy /y "%FRONTEND%\.env.local" "%FRONTEND%\.env.local.bak" >nul

(
  echo # Written by start.bat - edit freely. Never commit this file.
  echo SUPABASE_URL=!IN_URL!
  echo SUPABASE_ANON_KEY=!IN_KEY!
  echo ANTHROPIC_API_KEY=!IN_AI!
) > "%BACKEND%\.env"

(
  echo NEXT_PUBLIC_SUPABASE_URL=!IN_URL!
  echo NEXT_PUBLIC_SUPABASE_ANON_KEY=!IN_KEY!
  echo NEXT_PUBLIC_API_URL=http://localhost:%BACKEND_PORT%
) > "%FRONTEND%\.env.local"

echo.
echo Saved backend\.env and frontend\.env.local
if not defined IN_URL echo [WARNING] No Supabase URL, so sign-in will not work until you run  start.bat config
if not defined IN_KEY echo [WARNING] No Supabase key, so sign-in will not work until you run  start.bat config
if not defined IN_AI  echo [NOTE] No Anthropic key. Scanning and the API tester work, but Explain with Claude will show a setup message.
echo.
echo One-time Supabase dashboard settings, needed for the verification email link:
echo   Authentication  then  URL Configuration
echo     Site URL:       http://localhost:%FRONTEND_PORT%
echo     Redirect URLs:  http://localhost:%FRONTEND_PORT%/dashboard
echo   Tip: to skip email verification while testing, turn OFF
echo        Authentication  then  Providers  then  Email  then  Confirm email
exit /b 0

rem ----------------------------------------------------------------------
rem  Run
rem ----------------------------------------------------------------------
:do_run
if not exist "%VENVPY%" (
  call :die "Not set up yet." "Run:  start.bat setup"
  exit /b 1
)
call :need_node || exit /b 1
if not exist "%FRONTEND%\node_modules\next\dist\bin\next" (
  call :die "The frontend packages are not installed." "Run:  start.bat setup"
  exit /b 1
)

"%VENVPY%" "%CHECK%" busy %BACKEND_PORT%
if not errorlevel 1 (
  call :die "Port %BACKEND_PORT% is already in use. Maybe DevGuard AI is already running in another window." "Close that window, or use another port:" "set BACKEND_PORT=8001" "start.bat run"
  exit /b 1
)
"%VENVPY%" "%CHECK%" busy %FRONTEND_PORT%
if not errorlevel 1 (
  call :die "Port %FRONTEND_PORT% is already in use. Maybe DevGuard AI is already running in another window." "Close that window, or use another port:" "set FRONTEND_PORT=3001" "start.bat run"
  exit /b 1
)

echo.
echo === Starting the backend on port %BACKEND_PORT% ===
start "DevGuard AI - backend" cmd /k ""%SELF%" _backend"
"%VENVPY%" "%CHECK%" wait-http "http://127.0.0.1:%BACKEND_PORT%/api/health" 40
if errorlevel 1 (
  echo.
  echo The backend did not start. Look at the window titled  DevGuard AI - backend  for the error.
  echo Common fixes:
  echo   - A Python package is missing: run  start.bat setup
  echo   - The port is in use: run  set BACKEND_PORT=8001  and then  start.bat run
  echo.
  pause
  exit /b 1
)
echo Backend is up.
"%VENVPY%" "%CHECK%" health "http://127.0.0.1:%BACKEND_PORT%/api/health"

echo.
echo === Starting the frontend on port %FRONTEND_PORT% ===
start "DevGuard AI - frontend" cmd /k ""%SELF%" _frontend"
"%VENVPY%" "%CHECK%" wait-port %FRONTEND_PORT% 90
if errorlevel 1 (
  echo.
  echo The frontend did not start. Look at the window titled  DevGuard AI - frontend  for the error.
  echo.
  pause
  exit /b 1
)

echo.
echo ============================================================
echo   DevGuard AI is running
echo.
echo   App:       http://localhost:%FRONTEND_PORT%
echo   API docs:  http://localhost:%BACKEND_PORT%/docs
echo ============================================================
echo.
start "" "http://localhost:%FRONTEND_PORT%"
echo Your browser should open now. The first page takes a few seconds to compile.
echo.
echo To STOP DevGuard AI: press any key in this window.
echo You can also just close the two server windows.
pause >nul
taskkill /FI "WINDOWTITLE eq DevGuard AI - backend*" /T /F >nul 2>&1
taskkill /FI "WINDOWTITLE eq DevGuard AI - frontend*" /T /F >nul 2>&1
echo DevGuard AI stopped.
exit /b 0

rem ----------------------------------------------------------------------
rem  The two server windows - started by :do_run, not meant to be called by hand
rem ----------------------------------------------------------------------
:child_backend
title DevGuard AI - backend
cd /d "%BACKEND%"
set "PYTHONUNBUFFERED=1"
set "FRONTEND_ORIGINS=http://localhost:%FRONTEND_PORT%,http://127.0.0.1:%FRONTEND_PORT%"
"%VENVPY%" -m uvicorn app.main:app --host 127.0.0.1 --port %BACKEND_PORT%
echo.
echo The backend stopped. Read the message above. Press any key to close this window.
pause >nul
exit

:child_frontend
title DevGuard AI - frontend
cd /d "%FRONTEND%"
set "NEXT_PUBLIC_API_URL=http://localhost:%BACKEND_PORT%"
set "NEXT_TELEMETRY_DISABLED=1"
node "%FRONTEND%\node_modules\next\dist\bin\next" dev -p %FRONTEND_PORT%
echo.
echo The frontend stopped. Read the message above. Press any key to close this window.
pause >nul
exit
