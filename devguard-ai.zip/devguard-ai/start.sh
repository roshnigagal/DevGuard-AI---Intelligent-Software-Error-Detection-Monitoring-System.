#!/usr/bin/env bash
# DevGuard AI - one-file setup and launcher.
#
#   bash start.sh            set everything up (first time only) and start the app
#   bash start.sh setup      install and configure only
#   bash start.sh run        start only (after setup)
#   bash start.sh config     re-enter your Supabase / Anthropic keys
#   bash start.sh test       run the backend tests
#
# Works on macOS, Linux, WSL, and Git Bash on Windows.
# Every error is also saved in the logs/ folder - send me those files if something fails.

set -u

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BACKEND="$ROOT/backend"
FRONTEND="$ROOT/frontend"
LOGS="$ROOT/logs"
BACKEND_PORT="${BACKEND_PORT:-8000}"
FRONTEND_PORT="${FRONTEND_PORT:-3000}"
VENV_PY=""

if [ -t 1 ]; then
  BOLD=$'\033[1m'; RED=$'\033[31m'; GREEN=$'\033[32m'; YELLOW=$'\033[33m'; RESET=$'\033[0m'
else
  BOLD=""; RED=""; GREEN=""; YELLOW=""; RESET=""
fi

say()  { printf '%s\n' "$*"; }
step() { printf '\n%s==> %s%s\n' "$BOLD" "$*" "$RESET"; }
ok()   { printf '%s[ok]%s %s\n' "$GREEN" "$RESET" "$*"; }
warn() { printf '%s[!]%s %s\n' "$YELLOW" "$RESET" "$*"; }
die()  { printf '\n%sERROR:%s %s\n' "$RED" "$RESET" "$*" >&2; exit 1; }

mkdir -p "$LOGS"

# Run a command, show its output AND save it to logs/setup.log. Returns the command's exit code.
logged() {
  "$@" 2>&1 | tee -a "$LOGS/setup.log"
  return "${PIPESTATUS[0]}"
}

stamp_of() { cksum < "$1" | tr -d ' \n'; }

# ---------------------------------------------------------------- tools

find_python() {
  local c
  for c in python3 python "py -3"; do
    # shellcheck disable=SC2086
    if $c -c 'import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)' >/dev/null 2>&1; then
      echo "$c"
      return 0
    fi
  done
  return 1
}

need_node() {
  command -v node >/dev/null 2>&1 || die "Node.js was not found. Install the LTS version from https://nodejs.org, close and reopen your terminal, then run this again."
  command -v npm >/dev/null 2>&1 || die "npm was not found. Reinstall Node.js from https://nodejs.org (it includes npm)."
  local major
  major="$(node -p 'process.versions.node.split(".")[0]' 2>/dev/null || echo 0)"
  [ "$major" -ge 18 ] 2>/dev/null || die "Node.js $(node --version) is too old. Install Node.js 18 or newer (the LTS version) from https://nodejs.org."
}

venv_python() {
  if [ -x "$BACKEND/venv/bin/python" ]; then
    echo "$BACKEND/venv/bin/python"
  elif [ -x "$BACKEND/venv/Scripts/python.exe" ]; then
    echo "$BACKEND/venv/Scripts/python.exe"
  else
    return 1
  fi
}

# ---------------------------------------------------------------- setup

setup_backend() {
  step "Backend: Python environment"
  local PY
  PY="$(find_python)" || die "Python 3.10 or newer was not found.
  - Windows: install it from https://www.python.org/downloads/ and TICK 'Add python.exe to PATH'.
  - macOS:   brew install python
  - Ubuntu:  sudo apt install python3 python3-venv python3-pip
  Then close and reopen your terminal and run this again."
  # shellcheck disable=SC2086
  ok "Using $PY ($($PY --version 2>&1))"

  if ! venv_python >/dev/null; then
    say "Creating virtual environment (backend/venv)..."
    # shellcheck disable=SC2086
    logged $PY -m venv "$BACKEND/venv" || die "Could not create a virtual environment.
  On Ubuntu/Debian run:  sudo apt install python3-venv   and try again."
  fi
  VENV_PY="$(venv_python)" || die "The virtual environment was created but its Python was not found in backend/venv. Delete the backend/venv folder and run this again."

  if [ "${DEVGUARD_SKIP_INSTALL:-0}" = "1" ]; then
    warn "Skipping Python package install (DEVGUARD_SKIP_INSTALL=1)."
    return
  fi

  local want have=""
  want="$(stamp_of "$BACKEND/requirements.txt")"
  [ -f "$BACKEND/venv/.requirements.stamp" ] && have="$(cat "$BACKEND/venv/.requirements.stamp")"
  if [ "$want" = "$have" ]; then
    ok "Python packages already installed"
  else
    say "Installing Python packages (this can take a minute)..."
    logged "$VENV_PY" -m pip install -r "$BACKEND/requirements.txt" || die "pip could not install the Python packages.
  Read the error above (also saved in logs/setup.log). Most often it is a network problem - check your internet and run this again."
    echo "$want" > "$BACKEND/venv/.requirements.stamp"
    ok "Python packages installed"
  fi
}

setup_eslint() {
  step "Backend: ESLint (enables JavaScript scanning)"
  if [ "${DEVGUARD_SKIP_INSTALL:-0}" = "1" ]; then warn "Skipped."; return; fi
  if [ -d "$BACKEND/tools/eslint/node_modules/eslint" ]; then ok "ESLint already installed"; return; fi
  if ! command -v npm >/dev/null 2>&1; then
    warn "npm not found - JavaScript scanning will be skipped. Python scanning still works."
    return
  fi
  ( cd "$BACKEND/tools/eslint" && logged npm install --no-audit --no-fund --loglevel=error ) \
    && ok "ESLint installed" \
    || warn "ESLint did not install. The app still works; JavaScript files just will not be scanned."
}

setup_frontend() {
  step "Frontend: Node packages"
  need_node
  ok "Node $(node --version), npm $(npm --version)"
  if [ "${DEVGUARD_SKIP_INSTALL:-0}" = "1" ]; then warn "Skipping npm install (DEVGUARD_SKIP_INSTALL=1)."; return; fi

  local want have=""
  want="$(stamp_of "$FRONTEND/package.json")"
  [ -f "$FRONTEND/node_modules/.devguard.stamp" ] && have="$(cat "$FRONTEND/node_modules/.devguard.stamp")"
  if [ "$want" = "$have" ] && [ -d "$FRONTEND/node_modules/next" ]; then
    ok "Node packages already installed"
  else
    say "Installing Node packages (this can take a few minutes the first time)..."
    ( cd "$FRONTEND" && logged npm install --no-audit --no-fund ) || die "npm install failed.
  Read the error above (also saved in logs/setup.log). Check your internet connection and run this again."
    echo "$want" > "$FRONTEND/node_modules/.devguard.stamp"
    ok "Node packages installed"
  fi
}

# ---------------------------------------------------------------- configuration

clean() {
  local v="$1"
  v="${v//$'\r'/}"
  v="${v#"${v%%[![:space:]]*}"}"
  v="${v%"${v##*[![:space:]]}"}"
  v="${v#\"}"; v="${v%\"}"; v="${v#\'}"; v="${v%\'}"
  printf '%s' "$v"
}

# ask_value VARNAME "Prompt" secret(0|1) validator(url|key|none)
ask_value() {
  local var="$1" prompt="$2" secret="$3" kind="$4" val="" current="${!1:-}"
  if [ -n "$current" ]; then
    printf -v "$var" '%s' "$(clean "$current")"
    say "$var: using the value from your environment"
    return
  fi
  while true; do
    val=""
    if [ "$secret" = "1" ]; then
      read -r -s -p "$prompt" val || true; echo
    else
      read -r -p "$prompt" val || true
    fi
    val="$(clean "$val")"
    [ "$kind" = "url" ] && val="${val%/}"
    if [ -z "$val" ]; then break; fi                      # blank = skip
    case "$kind" in
      url) case "$val" in http://*|https://*) break ;; *) warn "That does not look like a URL. It should start with https:// (or press Enter to skip)." ;; esac ;;
      key) if [ "${#val}" -ge 20 ]; then break; else warn "That looks too short to be a key (or press Enter to skip)."; fi ;;
      *)   break ;;
    esac
  done
  printf -v "$var" '%s' "$val"
}

configure() {
  local force="${1:-0}"
  if [ "$force" != "1" ] && [ -f "$BACKEND/.env" ] && [ -f "$FRONTEND/.env.local" ]; then
    ok "Configuration files already exist (run 'bash start.sh config' to change them)"
    return
  fi

  step "Configuration"
  cat <<'EOF'
You need three values. Press Enter to skip any of them and fill them in later.

  Supabase (free, https://supabase.com) -> your project -> Project Settings -> API
     1. Project URL            looks like  https://abcdxyz.supabase.co
     2. anon / publishable key   a long text starting with eyJ... or sb_publishable_...
  Anthropic (optional, https://console.anthropic.com) -> API keys
     3. API key                starts with sk-ant-   (only needed for the "Explain with Claude" button)

EOF
  SUPABASE_URL="${SUPABASE_URL:-}"; SUPABASE_ANON_KEY="${SUPABASE_ANON_KEY:-}"; ANTHROPIC_API_KEY="${ANTHROPIC_API_KEY:-}"
  ask_value SUPABASE_URL       "1. Supabase Project URL:        " 0 url
  ask_value SUPABASE_ANON_KEY  "2. Supabase anon/public key:    " 1 key
  ask_value ANTHROPIC_API_KEY  "3. Anthropic API key (optional): " 1 none

  [ -f "$BACKEND/.env" ]        && cp "$BACKEND/.env" "$BACKEND/.env.bak"
  [ -f "$FRONTEND/.env.local" ] && cp "$FRONTEND/.env.local" "$FRONTEND/.env.local.bak"

  {
    echo "# Written by start.sh - edit freely. Never commit this file."
    echo "SUPABASE_URL=$SUPABASE_URL"
    echo "SUPABASE_ANON_KEY=$SUPABASE_ANON_KEY"
    echo "ANTHROPIC_API_KEY=$ANTHROPIC_API_KEY"
  } > "$BACKEND/.env"
  chmod 600 "$BACKEND/.env" 2>/dev/null || true

  {
    echo "NEXT_PUBLIC_SUPABASE_URL=$SUPABASE_URL"
    echo "NEXT_PUBLIC_SUPABASE_ANON_KEY=$SUPABASE_ANON_KEY"
    echo "NEXT_PUBLIC_API_URL=http://localhost:$BACKEND_PORT"
  } > "$FRONTEND/.env.local"

  ok "Saved backend/.env and frontend/.env.local"
  [ -z "$SUPABASE_URL" ] || [ -z "$SUPABASE_ANON_KEY" ] && \
    warn "Supabase values are empty, so sign-in will not work until you run 'bash start.sh config' (or edit both files)."
  [ -z "$ANTHROPIC_API_KEY" ] && \
    warn "No Anthropic key: scanning and the API tester work, but 'Explain with Claude' will show a setup message."

  cat <<EOF

${BOLD}One-time Supabase dashboard settings${RESET} (needed for the verification email link):
  Authentication -> URL Configuration
    Site URL:       http://localhost:$FRONTEND_PORT
    Redirect URLs:  http://localhost:$FRONTEND_PORT/dashboard
  Tip: to skip email verification while testing, turn OFF
       Authentication -> Providers -> Email -> "Confirm email".
EOF
}

setup_all() {
  setup_backend
  setup_eslint
  setup_frontend
  configure 0
}

# ---------------------------------------------------------------- run

port_busy() {
  "$VENV_PY" - "$1" <<'PY'
import socket, sys
s = socket.socket()
s.settimeout(1)
busy = s.connect_ex(("127.0.0.1", int(sys.argv[1]))) == 0
s.close()
sys.exit(0 if busy else 1)
PY
}

http_get() {
  "$VENV_PY" - "$1" <<'PY'
import sys, urllib.request
opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
print(opener.open(sys.argv[1], timeout=2).read().decode())
PY
}

kill_tree() {
  local pid="$1"
  command -v pkill >/dev/null 2>&1 && pkill -P "$pid" 2>/dev/null
  kill "$pid" 2>/dev/null
  return 0
}

cleanup() {
  [ "${CLEANED:-0}" = "1" ] && return
  CLEANED=1
  trap - INT TERM EXIT
  [ -n "${TAIL_PID:-}" ] && kill "$TAIL_PID" 2>/dev/null
  [ -n "${BACK_PID:-}" ] && kill_tree "$BACK_PID"
  [ -n "${FRONT_PID:-}" ] && kill_tree "$FRONT_PID"
  wait 2>/dev/null
  say ""
  say "DevGuard AI stopped."
}

diagnose() { # diagnose <logfile>
  local f="$1"
  say ""
  say "${BOLD}Last lines of $(basename "$f"):${RESET}"
  tail -n 25 "$f" 2>/dev/null | sed 's/^/    /'
  say ""
  if grep -q "No module named" "$f" 2>/dev/null; then
    say "${BOLD}Likely cause:${RESET} a Python package is missing. Run:  bash start.sh setup"
  elif grep -qi "address already in use\|only one usage of each socket" "$f" 2>/dev/null; then
    say "${BOLD}Likely cause:${RESET} the port is already used. Close the other program, or run with another port:"
    say "    BACKEND_PORT=8001 bash start.sh run"
  elif grep -q "psycopg2" "$f" 2>/dev/null; then
    say "${BOLD}Likely cause:${RESET} DATABASE_URL points to PostgreSQL. Run: backend/venv pip install -r backend/requirements-postgres.txt, or delete the DATABASE_URL line from backend/.env."
  fi
  say "Full log: $f"
}

run_all() {
  VENV_PY="$(venv_python)" || die "Not set up yet. Run:  bash start.sh setup"
  need_node
  [ -f "$FRONTEND/node_modules/next/dist/bin/next" ] || die "Frontend packages are not installed. Run:  bash start.sh setup"

  if port_busy "$BACKEND_PORT"; then
    die "Port $BACKEND_PORT is already in use (maybe DevGuard is already running in another terminal).
  Close it, or use another port:  BACKEND_PORT=8001 bash start.sh run"
  fi
  if port_busy "$FRONTEND_PORT"; then
    die "Port $FRONTEND_PORT is already in use (maybe DevGuard is already running in another terminal).
  Close it, or use another port:  FRONTEND_PORT=3001 bash start.sh run"
  fi

  : > "$LOGS/backend.log"
  : > "$LOGS/frontend.log"
  trap cleanup INT TERM EXIT

  step "Starting the backend (port $BACKEND_PORT)"
  (
    cd "$BACKEND" || exit 1
    export PYTHONUNBUFFERED=1
    export FRONTEND_ORIGINS="http://localhost:$FRONTEND_PORT,http://127.0.0.1:$FRONTEND_PORT"
    exec "$VENV_PY" -m uvicorn app.main:app --host 127.0.0.1 --port "$BACKEND_PORT"
  ) >"$LOGS/backend.log" 2>&1 &
  BACK_PID=$!

  local up=0 i
  for i in $(seq 1 80); do
    if ! kill -0 "$BACK_PID" 2>/dev/null; then break; fi
    if http_get "http://127.0.0.1:$BACKEND_PORT/api/health" >/dev/null 2>&1; then up=1; break; fi
    sleep 0.5
  done
  if [ "$up" != "1" ]; then
    printf '%sThe backend did not start.%s\n' "$RED" "$RESET"
    diagnose "$LOGS/backend.log"
    exit 1
  fi
  ok "Backend is up"
  local health
  health="$(http_get "http://127.0.0.1:$BACKEND_PORT/api/health" 2>/dev/null || true)"
  case "$health" in *'"auth_configured":false'*) warn "Supabase is not configured in backend/.env - sign-in will fail. Run: bash start.sh config" ;; esac
  case "$health" in *'"ai_configured":false'*)   warn "No Anthropic key in backend/.env - 'Explain with Claude' will be unavailable." ;; esac

  step "Starting the frontend (port $FRONTEND_PORT)"
  (
    cd "$FRONTEND" || exit 1
    export NEXT_PUBLIC_API_URL="http://localhost:$BACKEND_PORT"
    export NEXT_TELEMETRY_DISABLED=1
    exec node "$FRONTEND/node_modules/next/dist/bin/next" dev -p "$FRONTEND_PORT"
  ) >"$LOGS/frontend.log" 2>&1 &
  FRONT_PID=$!

  up=0
  for i in $(seq 1 120); do
    if ! kill -0 "$FRONT_PID" 2>/dev/null; then break; fi
    if port_busy "$FRONTEND_PORT"; then up=1; break; fi
    sleep 0.5
  done
  if [ "$up" != "1" ]; then
    printf '%sThe frontend did not start.%s\n' "$RED" "$RESET"
    diagnose "$LOGS/frontend.log"
    exit 1
  fi

  cat <<EOF

${GREEN}${BOLD}DevGuard AI is running${RESET}

   App:       ${BOLD}http://localhost:$FRONTEND_PORT${RESET}   <- open this in your browser
   API docs:  http://localhost:$BACKEND_PORT/docs

   Press Ctrl+C to stop. Logs: logs/backend.log and logs/frontend.log
   (The first page you open takes a few seconds to compile.)

EOF

  tail -n 0 -f "$LOGS/backend.log" "$LOGS/frontend.log" &
  TAIL_PID=$!

  while kill -0 "$BACK_PID" 2>/dev/null && kill -0 "$FRONT_PID" 2>/dev/null; do
    sleep 1
  done
  if ! kill -0 "$BACK_PID" 2>/dev/null; then
    printf '\n%sThe backend stopped unexpectedly.%s\n' "$RED" "$RESET"; diagnose "$LOGS/backend.log"
  else
    printf '\n%sThe frontend stopped unexpectedly.%s\n' "$RED" "$RESET"; diagnose "$LOGS/frontend.log"
  fi
  exit 1
}

run_tests() {
  VENV_PY="$(venv_python)" || die "Not set up yet. Run:  bash start.sh setup"
  ( cd "$BACKEND" && "$VENV_PY" -m unittest discover -s tests -t . )
}

usage() {
  sed -n '2,10p' "${BASH_SOURCE[0]}" | sed 's/^# \{0,1\}//'
}

# ---------------------------------------------------------------- main

case "${1:-start}" in
  start)  setup_all; run_all ;;
  setup)  setup_all; say ""; ok "Setup finished. Start the app with:  bash start.sh run" ;;
  run)    run_all ;;
  config) configure 1 ;;
  test)   run_tests ;;
  help|-h|--help) usage ;;
  *)      usage; exit 1 ;;
esac
